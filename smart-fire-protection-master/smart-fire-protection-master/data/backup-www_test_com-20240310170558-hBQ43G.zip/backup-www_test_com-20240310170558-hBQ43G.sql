-- SQL Dump by Erik Edgren
-- version 1.0
--
-- SQL Dump created: March 10th, 2024 @ 5:05 pm

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";



-- --------------------------------------------------------



--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_admin`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) DEFAULT '' COMMENT '昵称',
  `password` varchar(32) DEFAULT '' COMMENT '密码',
  `salt` varchar(30) DEFAULT '' COMMENT '密码盐',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `email` varchar(100) DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机号码',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `logintime` bigint(16) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) DEFAULT NULL COMMENT '登录IP',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(59) DEFAULT '' COMMENT 'Session标识',
  `status` varchar(30) NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';


--
-- List the data for the table
--

INSERT INTO `fa_admin` (`id`, `username`, `nickname`, `password`, `salt`, `avatar`, `email`, `mobile`, `loginfailure`, `logintime`, `loginip`, `createtime`, `updatetime`, `token`, `status`) VALUES
(1, 'admin', 'Admin', '2b40600551e2b166d26fbc973a894bed', 'fd3642', 'http://www.test.com/assets/img/avatar.png', 'admin@admin.com', '', 0, 1710057809, '127.0.0.1', 1491635035, 1710057809, 'f1e3da1e-117d-4213-aa35-0b6497d0ebcc', 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_apilog`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_apilog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(255) DEFAULT NULL COMMENT 'IP',
  `url` varchar(255) DEFAULT NULL COMMENT '请求地址',
  `method` enum('GET','POST','PUT','DELETE') DEFAULT NULL COMMENT '请求方法',
  `param` text COMMENT '参数',
  `ua` varchar(255) DEFAULT '' COMMENT 'UA',
  `controller` varchar(255) DEFAULT NULL COMMENT '控制器',
  `action` varchar(255) DEFAULT NULL COMMENT '操作',
  `time` float(11,6) DEFAULT '0.000000' COMMENT '耗时',
  `code` int(11) DEFAULT '200' COMMENT '状态码',
  `createtime` int(11) DEFAULT NULL COMMENT '请求时间',
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `response` text COMMENT '响应内容',
  PRIMARY KEY (`id`),
  KEY `createtime` (`createtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_area`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_area` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT NULL COMMENT '父id',
  `shortname` varchar(100) DEFAULT NULL COMMENT '简称',
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `mergename` varchar(255) DEFAULT NULL COMMENT '全称',
  `level` tinyint(4) DEFAULT NULL COMMENT '层级:1=省,2=市,3=区/县',
  `pinyin` varchar(100) DEFAULT NULL COMMENT '拼音',
  `code` varchar(100) DEFAULT NULL COMMENT '长途区号',
  `zip` varchar(100) DEFAULT NULL COMMENT '邮编',
  `first` varchar(50) DEFAULT NULL COMMENT '首字母',
  `lng` varchar(100) DEFAULT NULL COMMENT '经度',
  `lat` varchar(100) DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_attachment`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_attachment` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category` varchar(50) DEFAULT '' COMMENT '类别',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `url` varchar(255) DEFAULT '' COMMENT '物理路径',
  `imagewidth` varchar(30) DEFAULT '' COMMENT '宽度',
  `imageheight` varchar(30) DEFAULT '' COMMENT '高度',
  `imagetype` varchar(30) DEFAULT '' COMMENT '图片类型',
  `imageframes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '图片帧数',
  `filename` varchar(100) DEFAULT '' COMMENT '文件名称',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `mimetype` varchar(100) DEFAULT '' COMMENT 'mime类型',
  `extparam` varchar(255) DEFAULT '' COMMENT '透传数据',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建日期',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `uploadtime` bigint(16) DEFAULT NULL COMMENT '上传时间',
  `storage` varchar(100) NOT NULL DEFAULT 'local' COMMENT '存储位置',
  `sha1` varchar(40) DEFAULT '' COMMENT '文件 sha1编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='附件表';


--
-- List the data for the table
--

INSERT INTO `fa_attachment` (`id`, `category`, `admin_id`, `user_id`, `url`, `imagewidth`, `imageheight`, `imagetype`, `imageframes`, `filename`, `filesize`, `mimetype`, `extparam`, `createtime`, `updatetime`, `uploadtime`, `storage`, `sha1`) VALUES
(1, '', 1, 0, '/assets/img/qrcode.png', '150', '150', 'png', 0, 'qrcode.png', 21859, 'image/png', '', 1491635035, 1491635035, 1491635035, 'local', '17163603d0263e4838b9387ff2cd4877e8b018f6');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_auth_group`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_auth_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父组别',
  `name` varchar(100) DEFAULT '' COMMENT '组名',
  `rules` text NOT NULL COMMENT '规则ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='分组表';


--
-- List the data for the table
--

INSERT INTO `fa_auth_group` (`id`, `pid`, `name`, `rules`, `createtime`, `updatetime`, `status`) VALUES
(1, 0, 'Admin group', '*', 1491635035, 1491635035, 'normal'),
(2, 1, 'Second group', '13,14,16,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,40,41,42,43,44,45,46,47,48,49,50,55,56,57,58,59,60,61,62,63,64,65,1,9,10,11,7,6,8,2,4,5', 1491635035, 1491635035, 'normal'),
(3, 2, 'Third group', '1,4,9,10,11,13,14,15,16,17,40,41,42,43,44,45,46,47,48,49,50,55,56,57,58,59,60,61,62,63,64,65,5', 1491635035, 1491635035, 'normal'),
(4, 1, 'Second group 2', '1,4,13,14,15,16,17,55,56,57,58,59,60,61,62,63,64,65', 1491635035, 1491635035, 'normal'),
(5, 2, 'Third group 2', '1,2,6,7,8,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34', 1491635035, 1491635035, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_auth_group_access`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '会员ID',
  `group_id` int(10) unsigned NOT NULL COMMENT '级别ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限分组表';


--
-- List the data for the table
--

INSERT INTO `fa_auth_group_access` (`uid`, `group_id`) VALUES
(1, 1);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_auth_rule`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('menu','file') NOT NULL DEFAULT 'file' COMMENT 'menu为菜单,file为权限节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(100) DEFAULT '' COMMENT '规则名称',
  `title` varchar(50) DEFAULT '' COMMENT '规则名称',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `url` varchar(255) DEFAULT '' COMMENT '规则URL',
  `condition` varchar(255) DEFAULT '' COMMENT '条件',
  `remark` varchar(255) DEFAULT '' COMMENT '备注',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为菜单',
  `menutype` enum('addtabs','blank','dialog','ajax') DEFAULT NULL COMMENT '菜单类型',
  `extend` varchar(255) DEFAULT '' COMMENT '扩展属性',
  `py` varchar(30) DEFAULT '' COMMENT '拼音首字母',
  `pinyin` varchar(100) DEFAULT '' COMMENT '拼音',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `pid` (`pid`),
  KEY `weigh` (`weigh`)
) ENGINE=InnoDB AUTO_INCREMENT=379 DEFAULT CHARSET=utf8mb4 COMMENT='节点表';


--
-- List the data for the table
--

INSERT INTO `fa_auth_rule` (`id`, `type`, `pid`, `name`, `title`, `icon`, `url`, `condition`, `remark`, `ismenu`, `menutype`, `extend`, `py`, `pinyin`, `createtime`, `updatetime`, `weigh`, `status`) VALUES
(1, 'file', 0, 'dashboard', 'Dashboard', 'fa fa-dashboard', '', '', 'Dashboard tips', 0, NULL, '', 'kzt', 'kongzhitai', 1491635035, 1709888492, 0, 'normal'),
(2, 'file', 0, 'general', 'General', 'fa fa-cogs', '', '', '', 1, NULL, '', 'cggl', 'changguiguanli', 1491635035, 1491635035, 99, 'normal'),
(3, 'file', 0, 'category', 'Category', 'fa fa-leaf', '', '', 'Category tips', 0, NULL, '', 'flgl', 'fenleiguanli', 1491635035, 1491635035, 0, 'normal'),
(4, 'file', 0, 'addon', 'Addon', 'fa fa-rocket', '', '', 'Addon tips', 1, NULL, '', 'cjgl', 'chajianguanli', 1491635035, 1491635035, 0, 'normal'),
(5, 'file', 0, 'auth', '权限管理', 'fa fa-group', '', '', '', 1, 'addtabs', '', 'qxgl', 'quanxianguanli', 1491635035, 1709888554, 98, 'normal'),
(6, 'file', 2, 'general/config', 'Config', 'fa fa-cog', '', '', 'Config tips', 1, NULL, '', 'xtpz', 'xitongpeizhi', 1491635035, 1491635035, 60, 'normal'),
(7, 'file', 2, 'general/attachment', 'Attachment', 'fa fa-file-image-o', '', '', 'Attachment tips', 1, NULL, '', 'fjgl', 'fujianguanli', 1491635035, 1491635035, 53, 'normal'),
(8, 'file', 2, 'general/profile', 'Profile', 'fa fa-user', '', '', '', 1, NULL, '', 'grzl', 'gerenziliao', 1491635035, 1491635035, 34, 'normal'),
(9, 'file', 5, 'auth/admin', 'Admin', 'fa fa-user', '', '', 'Admin tips', 1, NULL, '', 'glygl', 'guanliyuanguanli', 1491635035, 1491635035, 118, 'normal'),
(10, 'file', 5, 'auth/adminlog', 'Admin log', 'fa fa-list-alt', '', '', 'Admin log tips', 1, NULL, '', 'glyrz', 'guanliyuanrizhi', 1491635035, 1491635035, 113, 'normal'),
(11, 'file', 5, 'auth/group', 'Group', 'fa fa-group', '', '', 'Group tips', 1, NULL, '', 'jsz', 'juesezu', 1491635035, 1491635035, 109, 'normal'),
(12, 'file', 5, 'auth/rule', 'Rule', 'fa fa-bars', '', '', 'Rule tips', 1, NULL, '', 'cdgz', 'caidanguize', 1491635035, 1491635035, 104, 'normal'),
(13, 'file', 1, 'dashboard/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 136, 'normal'),
(14, 'file', 1, 'dashboard/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 135, 'normal'),
(15, 'file', 1, 'dashboard/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 133, 'normal'),
(16, 'file', 1, 'dashboard/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 134, 'normal'),
(17, 'file', 1, 'dashboard/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 132, 'normal'),
(18, 'file', 6, 'general/config/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 52, 'normal'),
(19, 'file', 6, 'general/config/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 51, 'normal'),
(20, 'file', 6, 'general/config/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 50, 'normal'),
(21, 'file', 6, 'general/config/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 49, 'normal'),
(22, 'file', 6, 'general/config/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 48, 'normal'),
(23, 'file', 7, 'general/attachment/index', 'View', 'fa fa-circle-o', '', '', 'Attachment tips', 0, NULL, '', '', '', 1491635035, 1491635035, 59, 'normal'),
(24, 'file', 7, 'general/attachment/select', 'Select attachment', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 58, 'normal'),
(25, 'file', 7, 'general/attachment/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 57, 'normal'),
(26, 'file', 7, 'general/attachment/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 56, 'normal'),
(27, 'file', 7, 'general/attachment/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 55, 'normal'),
(28, 'file', 7, 'general/attachment/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 54, 'normal'),
(29, 'file', 8, 'general/profile/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 33, 'normal'),
(30, 'file', 8, 'general/profile/update', 'Update profile', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 32, 'normal'),
(31, 'file', 8, 'general/profile/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 31, 'normal'),
(32, 'file', 8, 'general/profile/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 30, 'normal'),
(33, 'file', 8, 'general/profile/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 29, 'normal'),
(34, 'file', 8, 'general/profile/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 28, 'normal'),
(35, 'file', 3, 'category/index', 'View', 'fa fa-circle-o', '', '', 'Category tips', 0, NULL, '', '', '', 1491635035, 1491635035, 142, 'normal'),
(36, 'file', 3, 'category/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 141, 'normal'),
(37, 'file', 3, 'category/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 140, 'normal'),
(38, 'file', 3, 'category/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 139, 'normal'),
(39, 'file', 3, 'category/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 138, 'normal'),
(40, 'file', 9, 'auth/admin/index', 'View', 'fa fa-circle-o', '', '', 'Admin tips', 0, NULL, '', '', '', 1491635035, 1491635035, 117, 'normal'),
(41, 'file', 9, 'auth/admin/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 116, 'normal'),
(42, 'file', 9, 'auth/admin/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 115, 'normal'),
(43, 'file', 9, 'auth/admin/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 114, 'normal'),
(44, 'file', 10, 'auth/adminlog/index', 'View', 'fa fa-circle-o', '', '', 'Admin log tips', 0, NULL, '', '', '', 1491635035, 1491635035, 112, 'normal'),
(45, 'file', 10, 'auth/adminlog/detail', 'Detail', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 111, 'normal'),
(46, 'file', 10, 'auth/adminlog/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 110, 'normal'),
(47, 'file', 11, 'auth/group/index', 'View', 'fa fa-circle-o', '', '', 'Group tips', 0, NULL, '', '', '', 1491635035, 1491635035, 108, 'normal'),
(48, 'file', 11, 'auth/group/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 107, 'normal'),
(49, 'file', 11, 'auth/group/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 106, 'normal'),
(50, 'file', 11, 'auth/group/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 105, 'normal'),
(51, 'file', 12, 'auth/rule/index', 'View', 'fa fa-circle-o', '', '', 'Rule tips', 0, NULL, '', '', '', 1491635035, 1491635035, 103, 'normal'),
(52, 'file', 12, 'auth/rule/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 102, 'normal'),
(53, 'file', 12, 'auth/rule/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 101, 'normal'),
(54, 'file', 12, 'auth/rule/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 100, 'normal'),
(55, 'file', 4, 'addon/index', 'View', 'fa fa-circle-o', '', '', 'Addon tips', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(56, 'file', 4, 'addon/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(57, 'file', 4, 'addon/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(58, 'file', 4, 'addon/del', 'Delete', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(59, 'file', 4, 'addon/downloaded', 'Local addon', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(60, 'file', 4, 'addon/state', 'Update state', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(63, 'file', 4, 'addon/config', 'Setting', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(64, 'file', 4, 'addon/refresh', 'Refresh', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(65, 'file', 4, 'addon/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(66, 'file', 0, 'user', 'User', 'fa fa-user-circle', '', '', '', 0, NULL, '', 'hygl', 'huiyuanguanli', 1491635035, 1709888509, 0, 'normal'),
(67, 'file', 66, 'user/user', 'User', 'fa fa-user', '', '', '', 1, NULL, '', 'hygl', 'huiyuanguanli', 1491635035, 1491635035, 0, 'normal'),
(68, 'file', 67, 'user/user/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(69, 'file', 67, 'user/user/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(70, 'file', 67, 'user/user/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(71, 'file', 67, 'user/user/del', 'Del', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(72, 'file', 67, 'user/user/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(73, 'file', 66, 'user/group', 'User group', 'fa fa-users', '', '', '', 1, NULL, '', 'hyfz', 'huiyuanfenzu', 1491635035, 1491635035, 0, 'normal'),
(74, 'file', 73, 'user/group/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(75, 'file', 73, 'user/group/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(76, 'file', 73, 'user/group/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(77, 'file', 73, 'user/group/del', 'Del', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(78, 'file', 73, 'user/group/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(79, 'file', 66, 'user/rule', 'User rule', 'fa fa-circle-o', '', '', '', 1, NULL, '', 'hygz', 'huiyuanguize', 1491635035, 1491635035, 0, 'normal'),
(80, 'file', 79, 'user/rule/index', 'View', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(81, 'file', 79, 'user/rule/del', 'Del', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(82, 'file', 79, 'user/rule/add', 'Add', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(83, 'file', 79, 'user/rule/edit', 'Edit', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(84, 'file', 79, 'user/rule/multi', 'Multi', 'fa fa-circle-o', '', '', '', 0, NULL, '', '', '', 1491635035, 1491635035, 0, 'normal'),
(201, 'file', 0, 'equipment', '智慧消防设备管理', 'fa fa-microchip', '', '', '', 1, 'addtabs', '', 'zhxfsbgl', 'zhihuixiaofangshebeiguanli', 1709878090, 1709889204, 1000, 'normal'),
(202, 'file', 201, 'equipment/dashboard/index', '看板中心', 'fa fa-tachometer', '', '', '', 1, 'addtabs', '', 'kbzx', 'kanbanzhongxin', 1709878090, 1709991970, 19, 'normal'),
(203, 'file', 201, 'equipment/department', '部门管理', 'fa fa-users', '', '', '', 0, NULL, '', 'bmgl', 'bumenguanli', 1709878090, 1709878090, 0, 'normal'),
(204, 'file', 203, 'equipment/department/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878090, 1709878090, 0, 'normal'),
(205, 'file', 203, 'equipment/department/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878090, 1709878090, 0, 'normal'),
(206, 'file', 203, 'equipment/department/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709878090, 1709878090, 0, 'normal'),
(207, 'file', 203, 'equipment/department/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878090, 1709878090, 0, 'normal'),
(208, 'file', 203, 'equipment/department/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878090, 1709878090, 0, 'normal'),
(209, 'file', 203, 'equipment/department/recyclebin', '回收站', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hsz', 'huishouzhan', 1709878090, 1709878090, 0, 'normal'),
(210, 'file', 203, 'equipment/department/restore', '回收站-还原', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszhy', 'huishouzhanhuanyuan', 1709878090, 1709878090, 0, 'normal'),
(211, 'file', 203, 'equipment/department/destroy', '回收站-销毁', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszxh', 'huishouzhanxiaohui', 1709878090, 1709878090, 0, 'normal'),
(212, 'file', 201, 'equipment/staff', '员工管理', 'fa fa-user-circle', '', '', '', 1, 'addtabs', '', 'yggl', 'yuangongguanli', 1709878090, 1709991978, 18, 'normal'),
(213, 'file', 212, 'equipment/staff/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878090, 1709878090, 0, 'normal'),
(214, 'file', 212, 'equipment/staff/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878090, 1709878090, 0, 'normal'),
(215, 'file', 212, 'equipment/staff/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709878090, 1709878090, 0, 'normal'),
(216, 'file', 212, 'equipment/staff/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878090, 1709878090, 0, 'normal'),
(217, 'file', 212, 'equipment/staff/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878090, 1709878090, 0, 'normal'),
(218, 'file', 212, 'equipment/staff/picker', '员工选择弹窗(务必√)', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'ygxzdcwb', 'yuangongxuanzedanchuangwubi', 1709878090, 1709878090, 0, 'normal'),
(219, 'file', 212, 'equipment/staff/pickerDeal', '员工选择弹窗确认(务必√)', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'ygxzdcqrwb', 'yuangongxuanzedanchuangquerenwubi', 1709878090, 1709878090, 0, 'normal'),
(220, 'file', 212, 'equipment/staff/getPlanSelectpage', '选择员工(务必√)', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'xzygwb', 'xuanzeyuangongwubi', 1709878090, 1709878090, 0, 'normal'),
(221, 'file', 212, 'equipment/staff/unbind', '解绑微信小程序', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jbwxxcx', 'jiebangweixinxiaochengxu', 1709878090, 1709878090, 0, 'normal'),
(222, 'file', 212, 'equipment/staff/recyclebin', '回收站', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hsz', 'huishouzhan', 1709878090, 1709878090, 0, 'normal'),
(223, 'file', 212, 'equipment/staff/restore', '回收站-还原', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszhy', 'huishouzhanhuanyuan', 1709878090, 1709878090, 0, 'normal'),
(224, 'file', 212, 'equipment/staff/destroy', '回收站-销毁', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszxh', 'huishouzhanxiaohui', 1709878090, 1709878090, 0, 'normal'),
(225, 'file', 201, 'equipment/supplier', '供应商管理', 'fa fa-handshake-o', '', '', '', 1, 'addtabs', '', 'gysgl', 'gongyingshangguanli', 1709878090, 1709992000, 17, 'normal'),
(226, 'file', 225, 'equipment/supplier/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878090, 1709878090, 0, 'normal'),
(227, 'file', 225, 'equipment/supplier/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878090, 1709878090, 0, 'normal'),
(228, 'file', 225, 'equipment/supplier/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709878090, 1709878090, 0, 'normal'),
(229, 'file', 225, 'equipment/supplier/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878090, 1709878090, 0, 'normal'),
(230, 'file', 225, 'equipment/supplier/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878090, 1709878090, 0, 'normal'),
(231, 'file', 225, 'equipment/supplier/recyclebin', '回收站', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hsz', 'huishouzhan', 1709878090, 1709878090, 0, 'normal'),
(232, 'file', 225, 'equipment/supplier/restore', '回收站-还原', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszhy', 'huishouzhanhuanyuan', 1709878090, 1709878090, 0, 'normal'),
(233, 'file', 225, 'equipment/supplier/destroy', '回收站-销毁', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszxh', 'huishouzhanxiaohui', 1709878090, 1709878090, 0, 'normal'),
(234, 'file', 201, 'equipment/archive', '设备档案', 'fa fa-archive', '', '', '', 1, 'addtabs', '', 'sbda', 'shebeidangan', 1709878090, 1709992011, 16, 'normal'),
(235, 'file', 234, 'equipment/archive/import', '导入', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dr', 'daoru', 1709878090, 1709878090, 0, 'normal'),
(236, 'file', 234, 'equipment/archive/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878090, 1709878090, 0, 'normal'),
(237, 'file', 234, 'equipment/archive/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878090, 1709878090, 0, 'normal'),
(238, 'file', 234, 'equipment/archive/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709878091, 1709878091, 0, 'normal'),
(239, 'file', 234, 'equipment/archive/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878091, 1709878091, 0, 'normal'),
(240, 'file', 234, 'equipment/archive/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878091, 1709878091, 0, 'normal'),
(241, 'file', 234, 'equipment/archive/exportTag', '导出标签数据', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dcbqsj', 'daochubiaoqianshuju', 1709878091, 1709878091, 0, 'normal'),
(242, 'file', 201, 'equipment/equipment', '设备列表', 'fa fa-list', '', '', '', 0, NULL, '', 'sblb', 'shebeiliebiao', 1709878091, 1709878091, 0, 'normal'),
(243, 'file', 242, 'equipment/equipment/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878091, 1709878091, 0, 'normal'),
(244, 'file', 242, 'equipment/equipment/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878091, 1709878091, 0, 'normal'),
(245, 'file', 242, 'equipment/equipment/qrcode', '二维码标签', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'ewmbq', 'erweimabiaoqian', 1709878091, 1709878091, 0, 'normal'),
(246, 'file', 201, 'equipment/inspection', '巡检计划', 'fa fa-recycle', '', '', '', 1, 'addtabs', '', 'xjjh', 'xunjianjihua', 1709878091, 1709992021, 15, 'normal'),
(247, 'file', 246, 'equipment/inspection/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878091, 1709878091, 0, 'normal'),
(248, 'file', 246, 'equipment/inspection/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878091, 1709878091, 0, 'normal'),
(249, 'file', 246, 'equipment/inspection/deactivated', '已停用计划', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'ytyjh', 'yitingyongjihua', 1709878091, 1709878091, 0, 'normal'),
(250, 'file', 201, 'equipment/maintenance', '保养计划', 'fa fa-clock-o', '', '', '', 1, 'addtabs', '', 'byjh', 'baoyangjihua', 1709878091, 1709992034, 14, 'normal'),
(251, 'file', 250, 'equipment/maintenance/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878091, 1709878091, 0, 'normal'),
(252, 'file', 250, 'equipment/maintenance/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878091, 1709878091, 0, 'normal'),
(253, 'file', 250, 'equipment/maintenance/deactivated', '已停用计划', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'ytyjh', 'yitingyongjihua', 1709878091, 1709878091, 0, 'normal'),
(254, 'file', 201, 'equipment/plan', '设备计划', 'fa fa-recycle', '', '', '', 0, NULL, '', 'sbjh', 'shebeijihua', 1709878091, 1709878091, 0, 'normal'),
(255, 'file', 254, 'equipment/plan/stop', '计划停用', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jhty', 'jihuatingyong', 1709878091, 1709878091, 0, 'normal'),
(256, 'file', 254, 'equipment/plan/list', '设备明细', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sbmx', 'shebeimingxi', 1709878091, 1709878091, 0, 'normal'),
(257, 'file', 254, 'equipment/plan/clearInvalidTask', '清理无效任务', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'qlwxrw', 'qingliwuxiaorenwu', 1709878091, 1709878091, 0, 'normal'),
(258, 'file', 254, 'equipment/plan_field/fields', '检查项', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jcx', 'jianchaxiang', 1709878091, 1709878091, 0, 'normal'),
(259, 'file', 201, 'equipment/record', '设备记录', 'fa fa-list-alt', '', '', '', 0, NULL, '', 'sbjl', 'shebeijilu', 1709878091, 1709878091, 0, 'normal'),
(260, 'file', 259, 'equipment/record/list', '记录明细', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jlmx', 'jilumingxi', 1709878091, 1709878091, 0, 'normal'),
(261, 'file', 259, 'equipment/record/detail', '记录详情', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jlxq', 'jiluxiangqing', 1709878091, 1709878091, 0, 'normal'),
(262, 'file', 201, 'equipment/repair', '维修工单', 'fa fa-wrench', '', '', '', 1, 'addtabs', '', 'wxgd', 'weixiugongdan', 1709878091, 1709991959, 20, 'normal'),
(263, 'file', 262, 'equipment/repair/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878091, 1709878091, 0, 'normal'),
(264, 'file', 262, 'equipment/repair/detail', '详情', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'xq', 'xiangqing', 1709878091, 1709878091, 0, 'normal'),
(265, 'file', 262, 'equipment/repair/assignment', '指派', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zp', 'zhipai', 1709878091, 1709878091, 0, 'normal'),
(266, 'file', 262, 'equipment/repair/register', '登记', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'dj', 'dengji', 1709878091, 1709878091, 0, 'normal'),
(267, 'file', 262, 'equipment/repair/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709878091, 1709878091, 0, 'normal'),
(268, 'file', 262, 'equipment/repair/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878091, 1709878091, 0, 'normal'),
(269, 'file', 262, 'equipment/repair/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878091, 1709878091, 0, 'normal'),
(270, 'file', 262, 'equipment/repair/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878091, 1709878091, 0, 'normal'),
(271, 'file', 201, 'equipment/failure_cause', '故障原因', 'fa fa-bug', '', '', '', 0, NULL, '', 'gzyy', 'guzhangyuanyin', 1709878091, 1709878091, 0, 'normal'),
(272, 'file', 271, 'equipment/failure_cause/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878091, 1709878091, 0, 'normal'),
(273, 'file', 271, 'equipment/failure_cause/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709878091, 1709878091, 0, 'normal'),
(274, 'file', 271, 'equipment/failure_cause/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878091, 1709878091, 0, 'normal'),
(275, 'file', 271, 'equipment/failure_cause/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878091, 1709878091, 0, 'normal'),
(276, 'file', 271, 'equipment/failure_cause/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878091, 1709878091, 0, 'normal'),
(277, 'file', 271, 'equipment/failure_cause/recyclebin', '回收站', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hsz', 'huishouzhan', 1709878091, 1709878091, 0, 'normal'),
(278, 'file', 271, 'equipment/failure_cause/restore', '回收站-还原', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszhy', 'huishouzhanhuanyuan', 1709878091, 1709878091, 0, 'normal'),
(279, 'file', 271, 'equipment/failure_cause/destroy', '回收站-销毁', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hszxh', 'huishouzhanxiaohui', 1709878091, 1709878091, 0, 'normal'),
(280, 'file', 201, 'equipment/reminder_users', '提醒人员', 'fa fa-bullhorn', '', '', '', 0, NULL, '', 'txry', 'tixingrenyuan', 1709878091, 1709878091, 0, 'normal'),
(281, 'file', 280, 'equipment/reminder_users/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709878091, 1709878091, 0, 'normal'),
(282, 'file', 280, 'equipment/reminder_users/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709878091, 1709878091, 0, 'normal'),
(283, 'file', 280, 'equipment/reminder_users/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709878091, 1709878091, 0, 'normal'),
(284, 'file', 280, 'equipment/reminder_users/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709878091, 1709878091, 0, 'normal'),
(285, 'file', 0, 'apilog', 'API访问监测分析', 'fa fa-pie-chart', '', '', '', 1, NULL, '', 'Afwjcfx', 'APIfangwenjiancefenxi', 1709880233, 1709880233, 143, 'normal'),
(286, 'file', 285, 'apilog/data', '基础数据', 'fa fa-dashboard', '', '', '', 1, NULL, '', 'jcsj', 'jichushuju', 1709880233, 1709880233, 0, 'normal'),
(287, 'file', 286, 'apilog/data/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709880233, 1709880233, 0, 'normal'),
(288, 'file', 285, 'apilog/trend', '趋势数据', 'fa fa-area-chart', '', '', '', 1, NULL, '', 'qssj', 'qushishuju', 1709880233, 1709880233, 0, 'normal'),
(289, 'file', 288, 'apilog/trend/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709880233, 1709880233, 0, 'normal'),
(290, 'file', 285, 'apilog/index', '请求列表', 'fa fa-list', '', '', '', 1, NULL, '', 'qqlb', 'qingqiuliebiao', 1709880233, 1709880233, 0, 'normal'),
(291, 'file', 290, 'apilog/index/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709880233, 1709880233, 0, 'normal'),
(292, 'file', 290, 'apilog/index/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709880233, 1709880233, 0, 'normal'),
(293, 'file', 290, 'apilog/index/detail', '详情', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'xq', 'xiangqing', 1709880233, 1709880233, 0, 'normal'),
(294, 'file', 290, 'apilog/index/banip', '禁用IP', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jyI', 'jinyongIP', 1709880233, 1709880233, 0, 'normal'),
(295, 'file', 0, 'webscan', '安全防护', 'fa fa-shield', '', '', '', 1, NULL, '', 'aqfh', 'anquanfanghu', 1709880245, 1709880245, 137, 'normal'),
(296, 'file', 295, 'webscan/webscanlog/dashboard', '攻击概括', 'fa fa-bar-chart-o', '', '', '', 1, NULL, '', 'gjgk', 'gongjigaikuo', 1709880245, 1709880245, 0, 'normal'),
(297, 'file', 295, 'webscan/verifies', '文件校验', 'fa fa-history', '', '', '', 1, NULL, '', 'wjjy', 'wenjianjiaoyan', 1709880245, 1709880245, 0, 'normal'),
(298, 'file', 297, 'webscan/verifies/index', '校验首页', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jysy', 'jiaoyanshouye', 1709880245, 1709880245, 0, 'normal'),
(299, 'file', 297, 'webscan/verifies/show', '查看文件', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zkwj', 'zhakanwenjian', 1709880245, 1709880245, 0, 'normal'),
(300, 'file', 297, 'webscan/verifies/trust', '加入信任', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jrxr', 'jiaruxinren', 1709880245, 1709880245, 0, 'normal'),
(301, 'file', 297, 'webscan/verifies/trusts', '批量信任', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plxr', 'piliangxinren', 1709880245, 1709880245, 0, 'normal'),
(302, 'file', 297, 'webscan/verifies/build', '初始化数据', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'cshsj', 'chushihuashuju', 1709880245, 1709880245, 0, 'normal'),
(303, 'file', 297, 'webscan/verifies/bianli', '遍历检查', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bljc', 'bianlijiancha', 1709880245, 1709880245, 0, 'normal'),
(304, 'file', 295, 'webscan/webscanlog', '攻击日志', 'fa fa-warning', '', '', '', 1, NULL, '', 'gjrz', 'gongjirizhi', 1709880245, 1709880245, 0, 'normal'),
(305, 'file', 304, 'webscan/webscanlog/index', '攻击日志', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'gjrz', 'gongjirizhi', 1709880245, 1709880245, 0, 'normal'),
(306, 'file', 304, 'webscan/webscanlog/black', '加入黑名单', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'jrhmd', 'jiaruheimingdan', 1709880245, 1709880245, 0, 'normal'),
(307, 'file', 0, 'notice', '消息管理', 'fa fa-bullhorn', '', '', '', 1, 'addtabs', '', 'xxgl', 'xiaoxiguanli', 1709880274, 1709888540, 120, 'normal'),
(308, 'file', 307, 'notice/event', '消息事件', 'fa fa-align-center', '', '', '', 1, 'addtabs', '', 'xxsj', 'xiaoxishijian', 1709880274, 1709880274, 198, 'normal'),
(309, 'file', 308, 'notice/event/import', '导入', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'dr', 'daoru', 1709880274, 1709880274, 0, 'normal'),
(310, 'file', 308, 'notice/event/index', '查看', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zk', 'zhakan', 1709880274, 1709880274, 0, 'normal'),
(311, 'file', 308, 'notice/event/recyclebin', '回收站', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'hsz', 'huishouzhan', 1709880274, 1709880274, 0, 'normal'),
(312, 'file', 308, 'notice/event/add', '添加', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'tj', 'tianjia', 1709880274, 1709880274, 0, 'normal'),
(313, 'file', 308, 'notice/event/edit', '编辑', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'bj', 'bianji', 1709880274, 1709880274, 0, 'normal'),
(314, 'file', 308, 'notice/event/del', '删除', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'sc', 'shanchu', 1709880274, 1709880274, 0, 'normal'),
(315, 'file', 308, 'notice/event/destroy', '真实删除', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zssc', 'zhenshishanchu', 1709880274, 1709880274, 0, 'normal'),
(316, 'file', 308, 'notice/event/restore', '还原', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'hy', 'huanyuan', 1709880274, 1709880274, 0, 'normal'),
(317, 'file', 308, 'notice/event/multi', '批量更新', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'plgx', 'pilianggengxin', 1709880274, 1709880274, 0, 'normal'),
(318, 'file', 307, 'notice/template', '消息模版', 'fa fa-connectdevelop', '', '', '', 1, 'addtabs', '', 'xxmb', 'xiaoximoban', 1709880274, 1709880274, 197, 'normal'),
(319, 'file', 318, 'notice/template/import', '导入', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'dr', 'daoru', 1709880274, 1709880274, 0, 'normal'),
(320, 'file', 318, 'notice/template/index', '查看', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zk', 'zhakan', 1709880274, 1709880274, 0, 'normal'),
(321, 'file', 318, 'notice/template/add', '添加', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'tj', 'tianjia', 1709880274, 1709880274, 0, 'normal'),
(322, 'file', 318, 'notice/template/edit', '编辑', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'bj', 'bianji', 1709880274, 1709880274, 0, 'normal'),
(323, 'file', 318, 'notice/template/del', '删除', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'sc', 'shanchu', 1709880274, 1709880274, 0, 'normal'),
(324, 'file', 318, 'notice/template/multi', '批量更新', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'plgx', 'pilianggengxin', 1709880274, 1709880274, 0, 'normal'),
(325, 'file', 307, 'notice/notice', '消息通知', 'fa fa-list-ol', '', '', '', 1, 'addtabs', '', 'xxtz', 'xiaoxitongzhi', 1709880274, 1709880274, 0, 'normal'),
(326, 'file', 325, 'notice/notice/import', '导入', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'dr', 'daoru', 1709880274, 1709880274, 0, 'normal'),
(327, 'file', 325, 'notice/notice/index', '查看', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zk', 'zhakan', 1709880274, 1709880274, 0, 'normal'),
(328, 'file', 325, 'notice/notice/add', '添加', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'tj', 'tianjia', 1709880274, 1709880274, 0, 'normal'),
(329, 'file', 325, 'notice/notice/edit', '编辑', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'bj', 'bianji', 1709880274, 1709880274, 0, 'normal'),
(330, 'file', 325, 'notice/notice/del', '删除', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'sc', 'shanchu', 1709880274, 1709880274, 0, 'normal'),
(331, 'file', 325, 'notice/notice/multi', '批量更新', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'plgx', 'pilianggengxin', 1709880274, 1709880274, 0, 'normal'),
(332, 'file', 307, 'notice/admin', '我的消息', 'fa fa-bullhorn', '', '', '', 1, 'addtabs', '', 'wdxx', 'wodexiaoxi', 1709880274, 1709880274, 200, 'normal'),
(333, 'file', 332, 'notice/admin/index', '查看', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zk', 'zhakan', 1709880274, 1709880274, 0, 'normal'),
(334, 'file', 307, 'notice/admin_mptemplate', '管理员绑定微信(模版消息)', 'fa fa-circle-o', '', '', '', 1, 'addtabs', '', 'glybdwxmbxx', 'guanliyuanbangdingweixinmobanxiaoxi', 1709880274, 1709880274, -1, 'normal'),
(335, 'file', 334, 'notice/admin_mptemplate/import', '导入', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'dr', 'daoru', 1709880274, 1709880274, 0, 'normal'),
(336, 'file', 334, 'notice/admin_mptemplate/index', '查看', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zk', 'zhakan', 1709880274, 1709880274, 0, 'normal'),
(337, 'file', 334, 'notice/admin_mptemplate/recyclebin', '回收站', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'hsz', 'huishouzhan', 1709880274, 1709880274, 0, 'normal'),
(338, 'file', 334, 'notice/admin_mptemplate/add', '添加', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'tj', 'tianjia', 1709880274, 1709880274, 0, 'normal'),
(339, 'file', 334, 'notice/admin_mptemplate/edit', '编辑', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'bj', 'bianji', 1709880274, 1709880274, 0, 'normal'),
(340, 'file', 334, 'notice/admin_mptemplate/del', '删除', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'sc', 'shanchu', 1709880274, 1709880274, 0, 'normal'),
(341, 'file', 334, 'notice/admin_mptemplate/destroy', '真实删除', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'zssc', 'zhenshishanchu', 1709880274, 1709880274, 0, 'normal'),
(342, 'file', 334, 'notice/admin_mptemplate/restore', '还原', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'hy', 'huanyuan', 1709880274, 1709880274, 0, 'normal'),
(343, 'file', 334, 'notice/admin_mptemplate/multi', '批量更新', 'fa fa-circle-o', NULL, '', '', 0, NULL, NULL, 'plgx', 'pilianggengxin', 1709880274, 1709880274, 0, 'normal'),
(344, 'file', 2, 'general/logs', '日志管理', 'fa fa-pied-piper-alt', '', '', '', 1, NULL, '', 'rzgl', 'rizhiguanli', 1709889053, 1709889053, 0, 'normal'),
(345, 'file', 344, 'general/logs/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709889053, 1709889053, 0, 'normal'),
(346, 'file', 344, 'general/logs/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709889053, 1709889053, 0, 'normal'),
(347, 'file', 344, 'general/logs/detail', '详情', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'xq', 'xiangqing', 1709889053, 1709889053, 0, 'normal'),
(348, 'file', 2, 'general/database', '数据库管理', 'fa fa-database', '', '', '可进行一些简单的数据库表优化或修复，查看表结构和数据，也可以进行SQL语句的操作', 1, NULL, '', 'sjkgl', 'shujukuguanli', 1709889069, 1709889069, 0, 'normal'),
(349, 'file', 348, 'general/database/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709889069, 1709889069, 0, 'normal'),
(350, 'file', 348, 'general/database/query', '查询', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'cx', 'chaxun', 1709889069, 1709889069, 0, 'normal'),
(351, 'file', 348, 'general/database/backup', '备份', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bf', 'beifen', 1709889069, 1709889069, 0, 'normal'),
(352, 'file', 348, 'general/database/restore', '恢复', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'hf', 'huifu', 1709889069, 1709889069, 0, 'normal'),
(353, 'file', 0, 'command', '在线命令管理', 'fa fa-terminal', '', '', '', 1, NULL, '', 'zxmlgl', 'zaixianminglingguanli', 1709915615, 1709915615, 0, 'normal'),
(354, 'file', 353, 'command/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709915615, 1709915615, 0, 'normal'),
(355, 'file', 353, 'command/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709915615, 1709915615, 0, 'normal'),
(356, 'file', 353, 'command/detail', '详情', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'xq', 'xiangqing', 1709915615, 1709915615, 0, 'normal'),
(357, 'file', 353, 'command/command', '生成并执行命令', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'scbzxml', 'shengchengbingzhixingmingling', 1709915615, 1709915615, 0, 'normal'),
(358, 'file', 353, 'command/execute', '再次执行命令', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zczxml', 'zaicizhixingmingling', 1709915615, 1709915615, 0, 'normal'),
(359, 'file', 353, 'command/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709915615, 1709915615, 0, 'normal'),
(360, 'file', 353, 'command/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709915615, 1709915615, 0, 'normal'),
(361, 'file', 201, 'equipment/messagelog', '设备状态信息日志', 'fa fa-folder-open-o', '', '', '', 1, 'addtabs', '', 'sbztxxrz', 'shebeizhuangtaixinxirizhi', 1709916366, 1709991880, 0, 'normal'),
(362, 'file', 361, 'equipment/messagelog/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709916366, 1709916366, 0, 'normal'),
(363, 'file', 361, 'equipment/messagelog/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709916366, 1709916366, 0, 'normal'),
(364, 'file', 361, 'equipment/messagelog/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709916366, 1709916366, 0, 'normal'),
(365, 'file', 361, 'equipment/messagelog/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709916366, 1709916366, 0, 'normal'),
(366, 'file', 361, 'equipment/messagelog/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709916366, 1709916366, 0, 'normal'),
(367, 'file', 201, 'equipment/message', '设备状态信息', 'fa fa-wrench', '', '', '', 1, 'addtabs', '', 'sbztxx', 'shebeizhuangtaixinxi', 1709916366, 1709991925, 0, 'normal'),
(368, 'file', 367, 'equipment/message/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709916366, 1709916366, 0, 'normal'),
(369, 'file', 367, 'equipment/message/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709916366, 1709916366, 0, 'normal'),
(370, 'file', 367, 'equipment/message/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709916366, 1709916366, 0, 'normal'),
(371, 'file', 367, 'equipment/message/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709916366, 1709916366, 0, 'normal'),
(372, 'file', 367, 'equipment/message/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709916366, 1709916366, 0, 'normal'),
(373, 'file', 201, 'equipment/caution', '设备报警管理', 'fa fa-bell', '', '', '', 1, 'addtabs', '', 'sbbjgl', 'shebeibaojingguanli', 1709916466, 1709992046, 13, 'normal'),
(374, 'file', 373, 'equipment/caution/index', '查看', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'zk', 'zhakan', 1709916466, 1709916466, 0, 'normal'),
(375, 'file', 373, 'equipment/caution/add', '添加', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'tj', 'tianjia', 1709916466, 1709916466, 0, 'normal'),
(376, 'file', 373, 'equipment/caution/edit', '编辑', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'bj', 'bianji', 1709916466, 1709916466, 0, 'normal'),
(377, 'file', 373, 'equipment/caution/del', '删除', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'sc', 'shanchu', 1709916466, 1709916466, 0, 'normal'),
(378, 'file', 373, 'equipment/caution/multi', '批量更新', 'fa fa-circle-o', '', '', '', 0, NULL, '', 'plgx', 'pilianggengxin', 1709916466, 1709916466, 0, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_category`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `type` varchar(30) DEFAULT '' COMMENT '栏目类型',
  `name` varchar(30) DEFAULT '',
  `nickname` varchar(50) DEFAULT '',
  `flag` set('hot','index','recommend') DEFAULT '',
  `image` varchar(100) DEFAULT '' COMMENT '图片',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `diyname` varchar(30) DEFAULT '' COMMENT '自定义名称',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `weigh` (`weigh`,`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COMMENT='分类表';


--
-- List the data for the table
--

INSERT INTO `fa_category` (`id`, `pid`, `type`, `name`, `nickname`, `flag`, `image`, `keywords`, `description`, `diyname`, `createtime`, `updatetime`, `weigh`, `status`) VALUES
(1, 0, 'page', '官方新闻', 'news', 'recommend', '/assets/img/qrcode.png', '', '', 'news', 1491635035, 1491635035, 1, 'normal'),
(2, 0, 'page', '移动应用', 'mobileapp', 'hot', '/assets/img/qrcode.png', '', '', 'mobileapp', 1491635035, 1491635035, 2, 'normal'),
(3, 2, 'page', '微信公众号', 'wechatpublic', 'index', '/assets/img/qrcode.png', '', '', 'wechatpublic', 1491635035, 1491635035, 3, 'normal'),
(4, 2, 'page', 'Android开发', 'android', 'recommend', '/assets/img/qrcode.png', '', '', 'android', 1491635035, 1491635035, 4, 'normal'),
(5, 0, 'page', '软件产品', 'software', 'recommend', '/assets/img/qrcode.png', '', '', 'software', 1491635035, 1491635035, 5, 'normal'),
(6, 5, 'page', '网站建站', 'website', 'recommend', '/assets/img/qrcode.png', '', '', 'website', 1491635035, 1491635035, 6, 'normal'),
(7, 5, 'page', '企业管理软件', 'company', 'index', '/assets/img/qrcode.png', '', '', 'company', 1491635035, 1491635035, 7, 'normal'),
(8, 6, 'page', 'PC端', 'website-pc', 'recommend', '/assets/img/qrcode.png', '', '', 'website-pc', 1491635035, 1491635035, 8, 'normal'),
(9, 6, 'page', '移动端', 'website-mobile', 'recommend', '/assets/img/qrcode.png', '', '', 'website-mobile', 1491635035, 1491635035, 9, 'normal'),
(10, 7, 'page', 'CRM系统 ', 'company-crm', 'recommend', '/assets/img/qrcode.png', '', '', 'company-crm', 1491635035, 1491635035, 10, 'normal'),
(11, 7, 'page', 'SASS平台软件', 'company-sass', 'recommend', '/assets/img/qrcode.png', '', '', 'company-sass', 1491635035, 1491635035, 11, 'normal'),
(12, 0, 'test', '测试1', 'test1', 'recommend', '/assets/img/qrcode.png', '', '', 'test1', 1491635035, 1491635035, 12, 'normal'),
(13, 0, 'test', '测试2', 'test2', 'recommend', '/assets/img/qrcode.png', '', '', 'test2', 1491635035, 1491635035, 13, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_command`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_command` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '类型',
  `params` varchar(1500) NOT NULL DEFAULT '' COMMENT '参数',
  `command` varchar(1500) NOT NULL DEFAULT '' COMMENT '命令',
  `content` text COMMENT '返回结果',
  `executetime` bigint(16) unsigned DEFAULT NULL COMMENT '执行时间',
  `createtime` bigint(16) unsigned DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) unsigned DEFAULT NULL COMMENT '更新时间',
  `status` enum('successed','failured') NOT NULL DEFAULT 'failured' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='在线命令表';


--
-- List the data for the table
--

INSERT INTO `fa_command` (`id`, `type`, `params`, `command`, `content`, `executetime`, `createtime`, `updatetime`, `status`) VALUES
(1, 'crud', '[\"--table=fa_equipment_message\"]', 'php think crud --table=fa_equipment_message', 'Build Successed', 1709915640, 1709915640, 1709915640, 'successed'),
(2, 'crud', '[\"--table=fa_equipment_messagelog\"]', 'php think crud --table=fa_equipment_messagelog', 'Build Successed', 1709915645, 1709915645, 1709915645, 'successed'),
(3, 'crud', '[\"--delete=1\",\"--force=1\",\"--table=fa_equipment_messagelog\"]', 'php think crud --delete=1 --force=1 --table=fa_equipment_messagelog', 'D:\\phpstudy_pro\\WWW\\www.test.com\\public/../application/admin\\controller\\equipment\\Messagelog.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\public/../application/admin\\model\\equipment\\Messagelog.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\public/../application/admin\\validate\\equipment\\Messagelog.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\messagelog\\add.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\messagelog\\edit.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\messagelog\\index.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\messagelog\\recyclebin.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\lang\\zh-cn\\equipment\\messagelog.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\public\\assets\\js\\backend\\equipment\\messagelog.js\nDelete Successed', 1709915660, 1709915660, 1709915660, 'successed'),
(4, 'crud', '[\"--delete=1\",\"--force=1\",\"--table=fa_equipment_message\"]', 'php think crud --delete=1 --force=1 --table=fa_equipment_message', 'D:\\phpstudy_pro\\WWW\\www.test.com\\public/../application/admin\\controller\\equipment\\Message.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\public/../application/admin\\model\\equipment\\Message.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\public/../application/admin\\validate\\equipment\\Message.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\message\\add.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\message\\edit.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\message\\index.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\view\\equipment\\message\\recyclebin.html\nD:\\phpstudy_pro\\WWW\\www.test.com\\application\\admin\\lang\\zh-cn\\equipment\\message.php\nD:\\phpstudy_pro\\WWW\\www.test.com\\public\\assets\\js\\backend\\equipment\\message.js\nDelete Successed', 1709915663, 1709915663, 1709915663, 'successed'),
(5, 'crud', '[\"--table=fa_equipment_message\",\"--relation=fa_equipment_equipment\",\"--relationmode=belongsto\",\"--relationforeignkey=code\",\"--relationprimarykey=equipment_code\",\"--relationfields=work_status\",\"--relation=fa_equipment_archive\",\"--relationmode=belongsto\",\"--relationforeignkey=archive_id\",\"--relationprimarykey=id\",\"--relationfields=model,name,region,responsible_uid\"]', 'php think crud --table=fa_equipment_message --relation=fa_equipment_equipment --relationmode=belongsto --relationforeignkey=code --relationprimarykey=equipment_code --relationfields=work_status --relation=fa_equipment_archive --relationmode=belongsto --relationforeignkey=archive_id --relationprimarykey=id --relationfields=model,name,region,responsible_uid', 'Build Successed', 1709916265, 1709916265, 1709916265, 'successed'),
(6, 'crud', '[\"--table=fa_equipment_messagelog\",\"--relation=fa_equipment_archive\",\"--relationmode=belongsto\",\"--relationforeignkey=archive_id\",\"--relationprimarykey=id\",\"--relationfields=model,name,region,responsible_uid\",\"--relation=fa_equipment_equipment\",\"--relationmode=belongsto\",\"--relationforeignkey=code\",\"--relationprimarykey=equipment_code\",\"--relationfields=work_status\"]', 'php think crud --table=fa_equipment_messagelog --relation=fa_equipment_archive --relationmode=belongsto --relationforeignkey=archive_id --relationprimarykey=id --relationfields=model,name,region,responsible_uid --relation=fa_equipment_equipment --relationmode=belongsto --relationforeignkey=code --relationprimarykey=equipment_code --relationfields=work_status', 'Build Successed', 1709916335, 1709916335, 1709916335, 'successed'),
(7, 'menu', '[\"--controller=equipment\\/Messagelog\",\"--controller=equipment\\/Message\"]', 'php think menu --controller=equipment/Messagelog --controller=equipment/Message', 'Build Successed!', 1709916366, 1709916366, 1709916366, 'successed'),
(8, 'crud', '[\"--table=fa_equipment_caution\",\"--relation=fa_equipment_archive\",\"--relationmode=belongsto\",\"--relationforeignkey=archive_id\",\"--relationprimarykey=id\",\"--relationfields=model,name,region,responsible_uid\",\"--relation=fa_equipment_equipment\",\"--relationmode=belongsto\",\"--relationforeignkey=code\",\"--relationprimarykey=equipment_code\",\"--relationfields=work_status\"]', 'php think crud --table=fa_equipment_caution --relation=fa_equipment_archive --relationmode=belongsto --relationforeignkey=archive_id --relationprimarykey=id --relationfields=model,name,region,responsible_uid --relation=fa_equipment_equipment --relationmode=belongsto --relationforeignkey=code --relationprimarykey=equipment_code --relationfields=work_status', 'Build Successed', 1709916459, 1709916459, 1709916459, 'successed'),
(9, 'menu', '[\"--controller=equipment\\/Caution\"]', 'php think menu --controller=equipment/Caution', 'Build Successed!', 1709916466, 1709916466, 1709916466, 'successed');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_config`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT '' COMMENT '变量名',
  `group` varchar(30) DEFAULT '' COMMENT '分组',
  `title` varchar(100) DEFAULT '' COMMENT '变量标题',
  `tip` varchar(100) DEFAULT '' COMMENT '变量描述',
  `type` varchar(30) DEFAULT '' COMMENT '类型:string,text,int,bool,array,datetime,date,file',
  `visible` varchar(255) DEFAULT '' COMMENT '可见条件',
  `value` text COMMENT '变量值',
  `content` text COMMENT '变量字典数据',
  `rule` varchar(100) DEFAULT '' COMMENT '验证规则',
  `extend` varchar(255) DEFAULT '' COMMENT '扩展属性',
  `setting` varchar(255) DEFAULT '' COMMENT '配置',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';


--
-- List the data for the table
--

INSERT INTO `fa_config` (`id`, `name`, `group`, `title`, `tip`, `type`, `visible`, `value`, `content`, `rule`, `extend`, `setting`) VALUES
(1, 'name', 'basic', 'Site name', '请填写站点名称', 'string', '', '智慧消防检测系统', '', 'required', '', NULL),
(2, 'beian', 'basic', 'Beian', '粤ICP备15000000号-1', 'string', '', '', '', '', '', NULL),
(3, 'cdnurl', 'basic', 'Cdn url', '如果全站静态资源使用第三方云储存请配置该值', 'string', '', '', '', '', '', ''),
(4, 'version', 'basic', 'Version', '如果静态资源有变动请重新配置该值', 'string', '', '1.0.1', '', 'required', '', NULL),
(5, 'timezone', 'basic', 'Timezone', '', 'string', '', 'Asia/Shanghai', '', 'required', '', NULL),
(6, 'forbiddenip', 'basic', 'Forbidden ip', '一行一条记录', 'text', '', '', '', '', '', NULL),
(7, 'languages', 'basic', 'Languages', '', 'array', '', '{\"backend\":\"zh-cn\",\"frontend\":\"zh-cn\"}', '', 'required', '', NULL),
(8, 'fixedpage', 'basic', 'Fixed page', '请输入左侧菜单栏存在的链接', 'string', '', 'dashboard', '', 'required', '', NULL),
(9, 'categorytype', 'dictionary', 'Category type', '', 'array', '', '{\"default\":\"Default\",\"page\":\"Page\",\"article\":\"Article\",\"test\":\"Test\"}', '', '', '', ''),
(10, 'configgroup', 'dictionary', 'Config group', '', 'array', '', '{\"basic\":\"Basic\",\"email\":\"Email\",\"dictionary\":\"Dictionary\",\"user\":\"User\",\"example\":\"Example\"}', '', '', '', ''),
(11, 'mail_type', 'email', 'Mail type', '选择邮件发送方式', 'select', '', '1', '[\"请选择\",\"SMTP\"]', '', '', ''),
(12, 'mail_smtp_host', 'email', 'Mail smtp host', '错误的配置发送邮件会导致服务器超时', 'string', '', 'smtp.qq.com', '', '', '', ''),
(13, 'mail_smtp_port', 'email', 'Mail smtp port', '(不加密默认25,SSL默认465,TLS默认587)', 'string', '', '465', '', '', '', ''),
(14, 'mail_smtp_user', 'email', 'Mail smtp user', '（填写完整用户名）', 'string', '', '10000', '', '', '', ''),
(15, 'mail_smtp_pass', 'email', 'Mail smtp password', '（填写您的密码或授权码）', 'string', '', 'password', '', '', '', ''),
(16, 'mail_verify_type', 'email', 'Mail vertify type', '（SMTP验证方式[推荐SSL]）', 'select', '', '2', '[\"无\",\"TLS\",\"SSL\"]', '', '', ''),
(17, 'mail_from', 'email', 'Mail from', '', 'string', '', '10000@qq.com', '', '', '', ''),
(18, 'attachmentcategory', 'dictionary', 'Attachment category', '', 'array', '', '{\"category1\":\"Category1\",\"category2\":\"Category2\",\"custom\":\"Custom\"}', '', '', '', '');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_ems`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_ems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) DEFAULT '' COMMENT '事件',
  `email` varchar(100) DEFAULT '' COMMENT '邮箱',
  `code` varchar(10) DEFAULT '' COMMENT '验证码',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) DEFAULT '' COMMENT 'IP',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮箱验证码表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_archive`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_archive` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备型号',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备名称',
  `parameter` text COLLATE utf8mb4_unicode_ci COMMENT '设备参数',
  `amount` smallint(6) NOT NULL DEFAULT '0' COMMENT '设备数量',
  `supplier_id` bigint(20) DEFAULT '0' COMMENT '供应商',
  `purchasetime` bigint(16) DEFAULT '0' COMMENT '购置日期',
  `region` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '所在区域',
  `responsible_uid` bigint(20) DEFAULT '0' COMMENT '负责人',
  `document` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '设备文档',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备档案表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_archive` (`id`, `model`, `name`, `parameter`, `amount`, `supplier_id`, `purchasetime`, `region`, `responsible_uid`, `document`, `remark`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(16, 'MC-T1650-HCS', '智慧消防灭火箱(文澄楼)', '灭火级别：1A 55B，瓶身材质：碳钢', 8, 1, 1710000000, '文澄楼3~4楼', 201, '', '', 'normal', 1710061295, 1710061295, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_caution`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_caution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT '' COMMENT '设备编号',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `warning` varchar(255) DEFAULT '' COMMENT '报警信息',
  `createtime` bigint(16) DEFAULT NULL COMMENT '报警时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fa_equipment_caution_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='设备报警管理';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_department`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_department` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '部门名称',
  `equipment_manage` tinyint(1) NOT NULL DEFAULT '0' COMMENT '设备管理权限',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='部门管理表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_department` (`id`, `name`, `equipment_manage`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, '管理部门', 1, 'normal', 1669688745, 1669688745, NULL),
(2, '维修部门', 1, 'normal', 1669688757, 1669688757, NULL),
(3, '生产部门', 0, 'normal', 1669688764, 1669688764, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_equipment`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_equipment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `coding` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '唯一编码',
  `equipment_code` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备编号',
  `work_status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '设备状态',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备明细表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_equipment` (`id`, `archive_id`, `coding`, `equipment_code`, `work_status`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(63, 16, 'EPVLEIJX', 'E240310-017', 'normal', 'normal', 1710061295, 1710061295, NULL),
(64, 16, 'EOKWXETF', 'E240310-018', 'normal', 'normal', 1710061295, 1710061295, NULL),
(65, 16, 'EPEMJALT', 'E240310-019', 'normal', 'normal', 1710061295, 1710061295, NULL),
(66, 16, 'EAMVDYOB', 'E240310-020', 'normal', 'normal', 1710061295, 1710061295, NULL),
(67, 16, 'EMKFPRCY', 'E240310-021', 'normal', 'normal', 1710061295, 1710061295, NULL),
(68, 16, 'EFSYZUNT', 'E240310-022', 'normal', 'normal', 1710061295, 1710061295, NULL),
(69, 16, 'EGXJILKZ', 'E240310-023', 'normal', 'normal', 1710061295, 1710061295, NULL),
(70, 16, 'EUOQGPMX', 'E240310-024', 'normal', 'normal', 1710061295, 1710061295, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_failure_cause`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_failure_cause` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '故障原因',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备故障原因表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_failure_cause` (`id`, `name`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, '其他原因', 'normal', 1669709924, 1669709924, NULL),
(2, '配件质量问题', 'normal', 1669709929, 1669709929, NULL),
(3, '维护保养不到位', 'normal', 1669709935, 1669709935, NULL),
(4, '自然磨损', 'normal', 1669709945, 1669709945, NULL),
(5, '违规操作', 'normal', 1669709953, 1669709953, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_message`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT '' COMMENT '设备编号',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `temp` float(5,1) DEFAULT '0.0' COMMENT '温度',
  `hum` float(5,1) DEFAULT '0.0' COMMENT '湿度',
  `press` float(5,2) DEFAULT '0.00' COMMENT '气压',
  `light` float(5,2) DEFAULT '0.00' COMMENT '光照强度',
  `sta` int(11) DEFAULT '0' COMMENT '烟雾类型',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fa_equipment_message_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='设备状态信息';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_message` (`id`, `code`, `archive_id`, `temp`, `hum`, `press`, `light`, `sta`, `createtime`, `updatetime`, `deletetime`) VALUES
(23, 'E240310-017', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(24, 'E240310-018', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(25, 'E240310-019', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(26, 'E240310-020', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(27, 'E240310-021', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(28, 'E240310-022', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(29, 'E240310-023', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL),
(30, 'E240310-024', 16, 0.0, 0.0, 0.00, 0.00, 0, 1710061295, 1710061295, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_messagelog`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_messagelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT '' COMMENT '设备编号',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `temp` float(5,1) DEFAULT '0.0' COMMENT '温度',
  `hum` float(5,1) DEFAULT '0.0' COMMENT '湿度',
  `press` float(5,2) DEFAULT '0.00' COMMENT '气压',
  `light` float(5,2) DEFAULT '0.00' COMMENT '光照强度',
  `sta` int(11) DEFAULT '0' COMMENT '烟雾类型',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fa_equipment_messagelog_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='设备状态信息日志';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_plan`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_plan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `coding` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '唯一编码',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '计划名称',
  `type` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '计划类型',
  `periodicity` bigint(16) unsigned NOT NULL DEFAULT '1' COMMENT '计划周期',
  `first_duetime` bigint(16) DEFAULT NULL COMMENT '首次执行日期',
  `last_duetime` bigint(16) DEFAULT NULL COMMENT '计划结束日期',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_plan` (`id`, `coding`, `name`, `type`, `periodicity`, `first_duetime`, `last_duetime`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(7, 'POVRWGPB', '巡检计划001', 'inspection', 3, 1710086399, 1715356799, 'normal', 1710061331, 1710061331, NULL),
(8, 'PWKPGNMH', '保养计划001', 'maintenance', 7, 1710086399, 1715356799, 'normal', 1710061505, 1710061505, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_plan_archive`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_plan_archive` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `archive_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '档案ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划设备关联表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_plan_archive` (`id`, `plan_id`, `archive_id`, `createtime`, `deletetime`) VALUES
(14, 7, 16, 1710061331, NULL),
(15, 8, 16, 1710061505, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_plan_field`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_plan_field` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `label` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段名称',
  `name` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段命名',
  `type` char(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段类型',
  `default` char(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '默认值',
  `options` text COLLATE utf8mb4_unicode_ci COMMENT '选项',
  `attributes` text COLLATE utf8mb4_unicode_ci COMMENT '属性',
  `require` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否必填',
  `sort` tinyint(2) NOT NULL DEFAULT '99' COMMENT '排序',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划字段表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_plan_field` (`id`, `plan_id`, `label`, `name`, `type`, `default`, `options`, `attributes`, `require`, `sort`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(8, 8, '压力是否正常', 'input_0', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(9, 8, '保险装置的铅封、销闩等完好有效、未遗失', 'input_1', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(10, 8, '是否在有效期内', 'input_2', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(11, 8, '压把是否正常', 'input_3', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(12, 8, '喷射软管有无异常', 'input_4', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(13, 8, '灭火器使用状态', 'input_5', 'radio', '', '[\"\\u672a\\u4f7f\\u7528\",\"\\u4f7f\\u7528\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(14, 8, '气压', 'input_6', 'number', '', '[]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(15, 8, '温度', 'input_7', 'number', '', '[]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(16, 8, '湿度', 'input_8', 'number', '', '[]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(17, 8, '其它情况说明', 'input_9', 'text', '', '[]', NULL, 0, 99, 'normal', 1709891138, 1709891138, NULL),
(18, 7, '检测烟感报警器信号点、报警的正确性', 'input_0', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(19, 7, '柜内电板、各电器元件表面灰尘清理', 'input_1', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(20, 7, '电源检查', 'input_2', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(21, 7, '灭火器取下抖动防止结块，每个压力表指针在绿色区', 'input_3', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(22, 7, '柜体全面保养', 'input_4', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(23, 7, '其它情况说明', 'input_5', 'text', '', '[]', NULL, 0, 99, 'normal', 1709891859, 1709891859, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_plan_task`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_plan_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `coding` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '唯一编码',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `equipment_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '设备ID',
  `task_uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '处理人ID',
  `status` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT '状态',
  `starttime` bigint(16) DEFAULT NULL COMMENT '开始时间',
  `duetime` bigint(16) DEFAULT NULL COMMENT '到期时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划任务表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_plan_task` (`id`, `coding`, `plan_id`, `equipment_id`, `task_uid`, `status`, `starttime`, `duetime`, `createtime`, `updatetime`, `deletetime`) VALUES
(13869, 'TSYXPCGW', 7, 63, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13870, 'TVTZIBMW', 7, 64, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13871, 'TJGSPHYZ', 7, 65, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13872, 'TYJRQAOG', 7, 66, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13873, 'TTAOXMYU', 7, 67, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13874, 'TXDKTNJM', 7, 68, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13875, 'TRKQXBIE', 7, 69, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13876, 'TWYMDSCK', 7, 70, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13877, 'TKJNSMBG', 7, 63, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13878, 'TDCXZNJV', 7, 64, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13879, 'TJCBSQIU', 7, 65, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13880, 'TKWCYDNZ', 7, 66, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13881, 'TFHSRZGX', 7, 67, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13882, 'TIYWPQBC', 7, 68, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13883, 'TJZMQANO', 7, 69, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13884, 'TWXNMZGL', 7, 70, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13885, 'TVPXWYLN', 7, 63, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13886, 'TINMOVQS', 7, 64, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13887, 'TDHXURLF', 7, 65, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13888, 'TFBJMLWR', 7, 66, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13889, 'TADRGFNY', 7, 67, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13890, 'TZDKOXMC', 7, 68, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13891, 'TBEKYSFM', 7, 69, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13892, 'TEPQONVK', 7, 70, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13893, 'TNJTZIHY', 7, 63, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13894, 'TUCONMLJ', 7, 64, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13895, 'TMWUVRTZ', 7, 65, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13896, 'TFHDMENW', 7, 66, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13897, 'TRBTEYLC', 7, 67, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13898, 'TTEYMPRA', 7, 68, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13899, 'TWBQJLDG', 7, 69, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13900, 'TJREZLXP', 7, 70, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13901, 'TMNBUKQP', 7, 63, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13902, 'TPFCNKGO', 7, 64, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13903, 'TDJKUWMP', 7, 65, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13904, 'TALFHTSY', 7, 66, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13905, 'TGQMNWXY', 7, 67, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13906, 'TXOIEVTH', 7, 68, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13907, 'TIVTNWBK', 7, 69, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13908, 'TRKFCQOT', 7, 70, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13909, 'TKOVLMSD', 7, 63, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13910, 'TTSBLMKV', 7, 64, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13911, 'TBLQVFDK', 7, 65, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13912, 'TYAFGXBQ', 7, 66, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13913, 'TVWMGNHJ', 7, 67, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13914, 'TTZKYLQD', 7, 68, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13915, 'TUANZKEJ', 7, 69, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13916, 'TJFDOQSZ', 7, 70, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13917, 'TBIENOFX', 7, 63, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13918, 'TBDMPCYE', 7, 64, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13919, 'TSXVEPKQ', 7, 65, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13920, 'TKOBVUFZ', 7, 66, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13921, 'TKSXODPM', 7, 67, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13922, 'TQNEPGLZ', 7, 68, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13923, 'TIQKETYS', 7, 69, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13924, 'TRPMTCLG', 7, 70, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13925, 'TJKUVQWN', 7, 63, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13926, 'TROJYSEP', 7, 64, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13927, 'TOFKGBLV', 7, 65, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13928, 'TRAKXEZF', 7, 66, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13929, 'TQIPFMOB', 7, 67, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13930, 'TSJIQDOU', 7, 68, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13931, 'TQBWCNXK', 7, 69, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13932, 'TCGDBNKV', 7, 70, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13933, 'TKNTFQAJ', 7, 63, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13934, 'THSITGMU', 7, 64, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13935, 'THFYVDWJ', 7, 65, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13936, 'THZLOQPE', 7, 66, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13937, 'TJSNPZAG', 7, 67, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13938, 'TILVPXYB', 7, 68, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13939, 'TNUERXDY', 7, 69, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13940, 'TTZNOVDQ', 7, 70, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13941, 'TKNCEJQZ', 7, 63, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13942, 'TTCKGLZE', 7, 64, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13943, 'TUAKVXRS', 7, 65, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13944, 'TBYKHJFX', 7, 66, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13945, 'TAVIRCJB', 7, 67, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13946, 'TEDMNWOX', 7, 68, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13947, 'TZAOJSWG', 7, 69, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13948, 'THSOZKXD', 7, 70, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13949, 'TLRXCNGE', 7, 63, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13950, 'TNIVPOMW', 7, 64, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13951, 'TBWHQTRA', 7, 65, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13952, 'TGESOMLZ', 7, 66, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13953, 'TZMRDHYO', 7, 67, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13954, 'TNUSOGTL', 7, 68, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13955, 'TXMTIRSJ', 7, 69, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13956, 'TXSJANHQ', 7, 70, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13957, 'TPZGYKFR', 7, 63, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13958, 'THIOSLZG', 7, 64, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13959, 'TPESLGBZ', 7, 65, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13960, 'TIACMWVD', 7, 66, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13961, 'THQFTJWK', 7, 67, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13962, 'THAKYVFJ', 7, 68, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13963, 'TQXSJZNI', 7, 69, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13964, 'TWPYDMLX', 7, 70, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13965, 'TQGJYRWF', 7, 63, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13966, 'TBPWQKEI', 7, 64, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13967, 'TGSXEFCI', 7, 65, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13968, 'TVMPRIUF', 7, 66, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13969, 'TVHQLMTS', 7, 67, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13970, 'TGIOTWCQ', 7, 68, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13971, 'TVJZCRQH', 7, 69, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13972, 'TAJQWBCO', 7, 70, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13973, 'TMAHYBGS', 7, 63, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13974, 'TPHDUMXF', 7, 64, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13975, 'TMUTXSCV', 7, 65, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13976, 'TMGBHJCY', 7, 66, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13977, 'TPYWLHEK', 7, 67, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13978, 'TKNDEMLH', 7, 68, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13979, 'TKWSEZXP', 7, 69, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13980, 'TEJVUDHL', 7, 70, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13981, 'TSOVKDRQ', 7, 63, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13982, 'TFIMJNWS', 7, 64, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13983, 'TBRVPMDI', 7, 65, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13984, 'TOCWTXRI', 7, 66, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13985, 'TYRSNLOK', 7, 67, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13986, 'TQBFOISA', 7, 68, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13987, 'TROXWFYZ', 7, 69, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13988, 'TVBRCKUD', 7, 70, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13989, 'TSNMTVID', 7, 63, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13990, 'TLEPGKBM', 7, 64, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13991, 'TGDIVTQL', 7, 65, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13992, 'TRLBWAVU', 7, 66, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13993, 'TUZQCJHW', 7, 67, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13994, 'TYPVEBCK', 7, 68, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13995, 'TZUBWHMC', 7, 69, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13996, 'TCXNUGMJ', 7, 70, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13997, 'TSKFAMBY', 7, 63, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(13998, 'TOSRCBVH', 7, 64, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(13999, 'TDLHEIFR', 7, 65, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14000, 'TUHPASNT', 7, 66, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14001, 'TRSVIPUF', 7, 67, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14002, 'TZUHMOQT', 7, 68, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14003, 'TCFGBLKP', 7, 69, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14004, 'TUEGPDBS', 7, 70, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14005, 'TCSWAPZU', 7, 63, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14006, 'TFLGCAED', 7, 64, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14007, 'TRJDWSLE', 7, 65, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14008, 'TFNPYXUW', 7, 66, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14009, 'TSUYTKMP', 7, 67, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14010, 'TOSVBEZJ', 7, 68, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14011, 'TKNSHGEL', 7, 69, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14012, 'TYUXKISP', 7, 70, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14013, 'TRYELIDH', 7, 63, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14014, 'TFRLJVOH', 7, 64, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14015, 'TPRMLNUE', 7, 65, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14016, 'TLBKEDAS', 7, 66, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14017, 'TMRUWNYS', 7, 67, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14018, 'TNYIHMLT', 7, 68, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14019, 'TJAVLQTF', 7, 69, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14020, 'TVEPRBQW', 7, 70, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14021, 'TCMHWINU', 7, 63, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14022, 'TKUWHSEP', 7, 64, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14023, 'TWGCLBPY', 7, 65, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14024, 'TBZGPRYM', 7, 66, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14025, 'TQXKCGPE', 7, 67, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14026, 'TCEPWFLJ', 7, 68, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14027, 'TNKLBPZO', 7, 69, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14028, 'TEXACKPH', 7, 70, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14029, 'TNUVIYJE', 7, 63, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14030, 'TOHIURSC', 7, 64, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14031, 'TIXTFBJG', 7, 65, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14032, 'TINYPAQU', 7, 66, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14033, 'TTWYVHRM', 7, 67, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14034, 'TJYCOHIN', 7, 68, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14035, 'TMPDFWZJ', 7, 69, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14036, 'TPVMNUSI', 7, 70, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14037, 'TGBUQXIV', 7, 63, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14038, 'TRQDZCVF', 7, 64, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14039, 'TAWFTGRV', 7, 65, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14040, 'TUGAOKJH', 7, 66, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14041, 'TUWHSAQG', 7, 67, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14042, 'TCJYAKNQ', 7, 68, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14043, 'TYQPBCLF', 7, 69, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14044, 'TUTIMXQC', 7, 70, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14045, 'TTUCLJIY', 8, 63, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14046, 'TJFLGHRZ', 8, 64, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14047, 'TOXZVDGH', 8, 65, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14048, 'TKPHESVC', 8, 66, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14049, 'TVLHSZRT', 8, 67, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14050, 'TGYBWHXL', 8, 68, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14051, 'TYHQDGUP', 8, 69, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14052, 'TGXUZERH', 8, 70, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14053, 'TMUBGFQE', 8, 63, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14054, 'TBSAWLIO', 8, 64, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14055, 'TGUYOWDB', 8, 65, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14056, 'TDYQASJO', 8, 66, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14057, 'TYUXDIQR', 8, 67, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14058, 'TJXRSGUL', 8, 68, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14059, 'TRFLQEKV', 8, 69, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14060, 'TNMUICLH', 8, 70, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14061, 'TNCVDWHO', 8, 63, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14062, 'TZSHTQJC', 8, 64, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14063, 'TKBDVHRN', 8, 65, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14064, 'TRXGMEIH', 8, 66, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14065, 'TOGSFVWK', 8, 67, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14066, 'TVOGHYEP', 8, 68, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14067, 'TIEKPOCL', 8, 69, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14068, 'TOTNAZJE', 8, 70, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14069, 'TCPAJTRD', 8, 63, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14070, 'TRAOBMGJ', 8, 64, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14071, 'TGZYMAQX', 8, 65, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14072, 'TVHQGKOL', 8, 66, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14073, 'TNQVYRMJ', 8, 67, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14074, 'TTEFPUXW', 8, 68, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14075, 'TEPAMDKR', 8, 69, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14076, 'TXUOATNH', 8, 70, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14077, 'TILWQYFB', 8, 63, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14078, 'TWFZMTRK', 8, 64, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14079, 'THALCJMI', 8, 65, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14080, 'TNRCBHYS', 8, 66, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14081, 'TENIYQVB', 8, 67, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14082, 'TUKCTOYN', 8, 68, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14083, 'TWBDHFQG', 8, 69, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14084, 'TVCYBEZD', 8, 70, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14085, 'TLAMXHZN', 8, 63, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14086, 'TSOYIJXQ', 8, 64, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14087, 'TFWONQSJ', 8, 65, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14088, 'TJZONAFW', 8, 66, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14089, 'TGSVHFTW', 8, 67, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14090, 'TYCUEDLI', 8, 68, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14091, 'TBOLXKIW', 8, 69, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14092, 'TFIMYUJL', 8, 70, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14093, 'TPNTYOXQ', 8, 63, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14094, 'TQHNRBUI', 8, 64, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14095, 'TNTVJAIR', 8, 65, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14096, 'TMEAHGPN', 8, 66, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14097, 'TOEZXVLY', 8, 67, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14098, 'TDNHSJZF', 8, 68, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14099, 'TWMZRCDJ', 8, 69, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14100, 'TZBERWFA', 8, 70, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14101, 'TSJXOFVM', 8, 63, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14102, 'TZFRLKAQ', 8, 64, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14103, 'TKBQMTIU', 8, 65, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14104, 'TGLDSJKF', 8, 66, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14105, 'TODUPNHQ', 8, 67, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14106, 'TNZVMSPL', 8, 68, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14107, 'TFAJHOYS', 8, 69, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14108, 'TCAUGZTK', 8, 70, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14109, 'TCELSMWI', 8, 63, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14110, 'TQNCETOK', 8, 64, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14111, 'TKONAPSL', 8, 65, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14112, 'TBQIGSKJ', 8, 66, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14113, 'TTDMYCSU', 8, 67, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14114, 'TUXLOYIN', 8, 68, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14115, 'TOIVPFNR', 8, 69, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14116, 'TSMLHQPV', 8, 70, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14117, 'TNXBMWRG', 8, 63, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14118, 'TTXYOPRK', 8, 64, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14119, 'TWNUQVYS', 8, 65, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14120, 'TBIMVEOX', 8, 66, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14121, 'TDIWULNC', 8, 67, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14122, 'TAJUKBMZ', 8, 68, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14123, 'TELHTFAG', 8, 69, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14124, 'TVGHNSPL', 8, 70, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_plan_user`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_plan_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划用户关联表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_plan_user` (`id`, `plan_id`, `user_id`, `createtime`, `deletetime`) VALUES
(12, 7, 202, 1710061331, NULL),
(13, 7, 201, 1710061331, NULL),
(14, 8, 202, 1710061505, NULL),
(15, 8, 201, 1710061505, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_record`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `equipment_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '设备ID',
  `relate_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '关联ID',
  `add_uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '添加用户ID',
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '记录名称',
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '记录类型',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '记录内容',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备记录表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_reminder_users`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_reminder_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '员工ID',
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='提醒人员表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_repair`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_repair` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `repair_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '工单编号',
  `archive_id` bigint(20) unsigned NOT NULL COMMENT '档案ID',
  `equipment_id` bigint(20) unsigned NOT NULL COMMENT '设备ID',
  `register_uid` bigint(20) DEFAULT '0' COMMENT '报修人员',
  `registertime` bigint(16) DEFAULT '0' COMMENT '报修日期',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '报修登记',
  `register_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '报修配图',
  `repair_uid` bigint(20) DEFAULT '0' COMMENT '维修人员',
  `assigntime` bigint(16) DEFAULT '0' COMMENT '派单时间',
  `repairtime` bigint(16) DEFAULT '0' COMMENT '维修日期',
  `repair_content` text COLLATE utf8mb4_unicode_ci COMMENT '维修登记',
  `repair_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '维修配图',
  `failure_cause_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '故障原因ID',
  `consuming` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '维修耗时',
  `status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '维修状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备维修表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_staff`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_staff` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint(20) DEFAULT '0' COMMENT '用户ID',
  `department_id` bigint(20) DEFAULT '0' COMMENT '部门ID',
  `workno` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '工号',
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '职位',
  `openid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'OPENID',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='员工管理表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_staff` (`id`, `user_id`, `department_id`, `workno`, `position`, `openid`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 201, 1, 'T001', '技术总监', '', 'normal', 1669688805, 1709888853, NULL),
(2, 202, 2, 'T003', '维保工', '', 'normal', 1669690876, 1709888849, NULL),
(3, 203, 3, 'P002', '装配工', '', 'normal', 1669691760, 1669712262, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_equipment_supplier`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_equipment_supplier` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `supplier_code` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '供应商编号',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '供应商名称',
  `relationship` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '合作关系',
  `bank` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '开户银行',
  `bank_account` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '银行账号',
  `contact` char(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '联系人',
  `contact_mobile` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '联系电话',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='供应商管理表';


--
-- List the data for the table
--

INSERT INTO `fa_equipment_supplier` (`id`, `supplier_code`, `name`, `relationship`, `bank`, `bank_account`, `contact`, `contact_mobile`, `remark`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 'GYS-0001', '成都成工消防器材有限公司', 'special', '成都银行郫都支行', '8888888888888888', '李四', '13456789871', '', 'normal', 1669690703, 1709888903, NULL),
(2, 'GYS-0002', '特级智慧消防设备供应有限公司', 'important', '建设银行郫都支行', '123123123123123', '王五', '13898764857', '', 'normal', 1669690738, 1709890266, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_blacklist`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_blacklist` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '被屏蔽人(KeFu用户ID)',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作客服',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服黑名单表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_captcha`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_captcha` (
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '验证码Key',
  `code` varchar(32) NOT NULL DEFAULT '' COMMENT '验证码',
  `captcha` varchar(6) NOT NULL DEFAULT '' COMMENT '验证码(供uniapp安卓二次生成图片)',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `expiretime` int(10) unsigned DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户验证码表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_config`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '变量名',
  `value` text COMMENT '变量值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COMMENT='客服配置表';


--
-- List the data for the table
--

INSERT INTO `fa_kefu_config` (`id`, `name`, `value`) VALUES
(1, 'chat_name', '在线客服'),
(2, 'ecs_exit', '1'),
(3, 'send_message_key', '1'),
(4, 'new_user_tip', '您准备好体验在线客服系统了吗？'),
(5, 'new_user_msg', '这是一个欢迎新用户的消息,系统为用户成功分配客服后,自动以该客服身份发送此消息~单客服的欢迎消息请于：客服管理-》客服代表管理进行设置'),
(6, 'csr_distribution', '2'),
(7, 'announcement', '这是一条公告！你可以在后台管理->客服管理->会话窗口中进行更换公告内容！'),
(8, 'slider_images', '/assets/addons/kefu/img/slider1.jpg,/assets/addons/kefu/img/slider2.jpg'),
(9, 'chat_introduces', '<p style=\"line-height: 1.6;\">\r\n  <b><span style=\"font-size: 16px;\">功能简介</span></b><br>\r\n</p>\r\n<p>\r\n <b>模块化开发</b><br>\r\n  强大的一键生成功能极速简化你的开发流程,加快你的项目开发\r\n</p>\r\n<p>\r\n <b>响应式布局</b><br>\r\n  自动适配,无需要担心兼容性问题\r\n</p>\r\n<p>\r\n  <b>完善的权限管理</b><br>\r\n  自由分配子级权限、一个管理员可同时属于多个组别\r\n</p>\r\n<p>\r\n  <b>通用的会员和API模块</b><br>\r\n  共用同一账号体系的Web端会员中心权限验证和API接口会员权限验证\r\n</p>\r\n<p>\r\n  <b>丰富的应用市场</b><br>\r\n  第三方云存储、云短信、富文本编辑器、CMS、博客、文档生成，一切均可在线安装卸载\r\n</p>\r\n<p></p>'),
(10, 'auto_invitation_switch', '1'),
(11, 'auto_invitation_timing', '7'),
(12, 'invite_box_img', '/assets/addons/kefu/img/invite_box_img.jpg'),
(13, 'csr_admin', '1'),
(14, 'trajectory_save_cycle', '1'),
(15, 'wechat_app_id', ''),
(16, 'wechat_app_secret', ''),
(17, 'wechat_token', ''),
(18, 'wechat_encodingkey', ''),
(19, 'new_message_notice', ''),
(20, 'only_first_invitation', '1'),
(21, 'new_message_shake', '3'),
(22, 'only_csr_online_invitation', '1'),
(23, 'kbs_switch', '1'),
(24, 'input_status_display', '2'),
(25, 'uni_push_switch', '0'),
(26, 'uni_push_appid', ''),
(27, 'uni_push_appkey', ''),
(28, 'uni_push_master_secret', ''),
(29, 'package_name_android', '');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_csr_config`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_csr_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '绑定管理员',
  `ceiling` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '接待上限',
  `reception_count` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '当前接待量',
  `last_reception_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上次接待时间',
  `keep_alive` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否保持在线',
  `welcome_msg` text COMMENT '欢迎语',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态:0=离线,1=繁忙,2=离开,3=在线',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='客服代表(csr)配置表';


--
-- List the data for the table
--

INSERT INTO `fa_kefu_csr_config` (`id`, `admin_id`, `ceiling`, `reception_count`, `last_reception_time`, `keep_alive`, `welcome_msg`, `status`) VALUES
(1, 1, 8, 1, 1567046865, 0, '欢迎访问！', 0);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_fast_reply`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_fast_reply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属客服',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '标题',
  `content` text NOT NULL COMMENT '回复内容',
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '状态:0=关闭,1=启用',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `deletetime` int(10) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='快捷回复表';


--
-- List the data for the table
--

INSERT INTO `fa_kefu_fast_reply` (`id`, `admin_id`, `title`, `content`, `status`, `createtime`, `deletetime`) VALUES
(1, 0, '打招呼', '您好，请问有什么可以帮您？', '1', 1567332795, NULL),
(2, 0, '询问联系方式', '您可以提供下您的联系方式么？您的电话是？或者QQ，我们可以更方便的联系您！', '1', 1567338640, NULL),
(3, 0, '提示客户等待-处理中', '请稍等片刻，我们正在为您处理！', '1', 1567338672, NULL),
(4, 0, '提示客户等待-问', '我去问一下，您稍等片刻~', '1', 1567338693, NULL),
(5, 0, '道别', '那好，祝您生活愉快，再见！', '1', 1567338716, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_kbs`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_kbs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `questions` text COMMENT '知识点',
  `match` tinyint(3) unsigned NOT NULL DEFAULT '100' COMMENT '自动回复匹配度',
  `answer` text COMMENT '问题答案',
  `admin_id` varchar(100) NOT NULL DEFAULT '' COMMENT '限定客服生效',
  `status` enum('2','1','0') NOT NULL DEFAULT '0' COMMENT '状态:0=关闭,1=启用,2=启用为万能知识',
  `weigh` int(10) NOT NULL DEFAULT '1' COMMENT '权重',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `deletetime` int(10) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='知识库表';


--
-- List the data for the table
--

INSERT INTO `fa_kefu_kbs` (`id`, `questions`, `match`, `answer`, `admin_id`, `status`, `weigh`, `createtime`, `deletetime`) VALUES
(1, '万能知识', 100, '<p>我是来自知识库的万能知识~</p><p>我不计算匹配度，只要没有任何知识点被匹配到，且没被“限定客服生效”所限定，就会回复我了~</p><p><b><span style=\"font-size: 12px;\">万能知识常用于限定客服才生效，若不需要请直接从知识库删除。</span></b></p>', '1', '2', 1, 1574075097, NULL),
(2, '你好\r\n您好\r\n在吗\r\n在？\r\n在', 80, '<p>亲，在的呢~</p><p>这是一条来自知识库的自动回复~</p>', '', '1', 2, 1574072922, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_leave_message`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_leave_message` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户(KeFu用户ID)',
  `name` varchar(50) NOT NULL DEFAULT '' COMMENT '姓名',
  `contact` varchar(50) NOT NULL DEFAULT '' COMMENT '联系方式',
  `message` text COMMENT '留言内容',
  `createtime` int(10) unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户留言记录';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_reception_log`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_reception_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `csr_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '客服代表ID',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '用户(KeFu用户ID)',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '接待时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服接待记录';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_record`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `session_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '会话ID',
  `sender_identity` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '发送人身份:0=客服,1=用户',
  `sender_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送人ID',
  `message_type` tinyint(1) DEFAULT NULL COMMENT '消息类型:0=富文本,1=图片,2=文件,3=系统消息,4=商品卡片,5=订单卡片',
  `message` text COMMENT '消息',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态:0=未读,1=已读',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='聊天记录表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_session`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_session` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户',
  `csr_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '客服代表ID',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  `deletetime` int(10) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服会话表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_toolbar`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_toolbar` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `position` enum('frontend','backend','general') NOT NULL DEFAULT 'backend' COMMENT '工具位置:backend=后台,frontend=前台,general=通用',
  `mark` varchar(20) NOT NULL DEFAULT '' COMMENT '唯一标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '标题',
  `icon_image` varchar(200) NOT NULL DEFAULT '' COMMENT '图标',
  `data_api` varchar(200) NOT NULL DEFAULT '' COMMENT '数据接口Url',
  `card_url` varchar(200) NOT NULL DEFAULT '' COMMENT '消息卡片Url',
  `card_frontend_url` varchar(200) NOT NULL DEFAULT '' COMMENT '消息卡片Url(uni端)',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态:0=隐藏,1=正常',
  `deletetime` int(10) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='窗口工具栏表';


--
-- List the data for the table
--

INSERT INTO `fa_kefu_toolbar` (`id`, `position`, `mark`, `title`, `icon_image`, `data_api`, `card_url`, `card_frontend_url`, `status`, `deletetime`) VALUES
(1, 'frontend', 'order', '发送订单', '/assets/addons/kefu/img/order.png', '/api/Kefu/orderList', '/bISTVBHhuo.php/kefu/csrkpi', '', 0, NULL),
(2, 'frontend', 'goods', '发送商品', '/assets/addons/kefu/img/goods.png', '/api/Kefu/goodsList', '/bISTVBHhuo.php/user/user', '', 0, NULL),
(3, 'backend', 'fastreply', '快捷回复', '/assets/addons/kefu/img/fastreply.png', '', '', '', 1, NULL),
(4, 'general', 'link', '发送链接', '/assets/addons/kefu/img/link.png', '', '', '', 1, NULL),
(5, 'general', 'file', '发送文件', '/assets/addons/kefu/img/attachment.png', '', '', '', 1, NULL),
(6, 'general', 'expression', '发送表情', '/assets/addons/kefu/img/smiley.png', '', '', '', 1, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_trajectory`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_trajectory` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'KeFu用户',
  `csr_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '客服代表',
  `log_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '轨迹类型:0=访问,1=被邀请,2=开始对话,3=拒绝会话,4=客服添加,5=关闭页面,6=留言,7=其他',
  `note` text COMMENT '轨迹详情',
  `url` text COMMENT '轨迹额外数据',
  `referrer` text COMMENT '来路',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户轨迹表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_user`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '对应用户ID',
  `avatar` varchar(100) NOT NULL DEFAULT '' COMMENT '头像',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `referrer` varchar(255) NOT NULL DEFAULT '' COMMENT '用户来路',
  `contact` varchar(100) NOT NULL DEFAULT '' COMMENT '联系方式',
  `note` varchar(255) NOT NULL DEFAULT '' COMMENT '客服备注',
  `token` varchar(59) NOT NULL DEFAULT '' COMMENT 'Session标识',
  `wechat_openid` varchar(28) NOT NULL DEFAULT '' COMMENT '微信openid',
  `createtime` int(10) unsigned DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客服用户表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_kefu_user_push_clientid`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_kefu_user_push_clientid` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `source` varchar(10) NOT NULL DEFAULT '' COMMENT '用户身份标识',
  `clientid` varchar(32) NOT NULL DEFAULT '' COMMENT 'clientid',
  `platform` enum('android','ios') NOT NULL DEFAULT 'android' COMMENT '用户系统平台',
  `updatetime` int(10) unsigned DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户推送clientid表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_category`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='分类表';


--
-- List the data for the table
--

INSERT INTO `fa_miniform_category` (`id`, `name`, `createtime`, `updatetime`, `weigh`) VALUES
(1, '测试', 1709725365, 1709725365, 1);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_ceshi`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_ceshi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL COMMENT '会员ID',
  `project_id` int(10) DEFAULT NULL COMMENT '项目ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `signintime` bigint(16) DEFAULT NULL COMMENT '签到时间',
  `verificationtime` bigint(16) DEFAULT NULL COMMENT '核销时间',
  `memo` varchar(1500) DEFAULT '' COMMENT '备注',
  `status` enum('free','nonpayment','paid','canceled') DEFAULT 'free' COMMENT '状态:free=免费,nonpayment=未支付,paid=已支付,canceled=已取消',
  `name` varchar(50) DEFAULT '' COMMENT '姓名',
  `mobile` varchar(50) DEFAULT '' COMMENT '电话号码',
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `createtime` (`createtime`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='测试';


--
-- List the data for the table
--

INSERT INTO `fa_miniform_ceshi` (`id`, `user_id`, `project_id`, `createtime`, `updatetime`, `signintime`, `verificationtime`, `memo`, `status`, `name`, `mobile`) VALUES
(1, 1, 1, 1709725477, 1709725477, NULL, NULL, '', 'free', '测试', '13888888888');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_fields`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_fields` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `source` varchar(50) NOT NULL COMMENT '资源',
  `source_id` int(10) NOT NULL DEFAULT '0' COMMENT '资源ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '名称',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '类型',
  `title` varchar(30) NOT NULL DEFAULT '' COMMENT '标题',
  `content` text COMMENT '内容',
  `value` text COMMENT '变量值',
  `defaultvalue` varchar(100) NOT NULL DEFAULT '' COMMENT '默认值',
  `rule` varchar(100) DEFAULT '' COMMENT '验证规则',
  `msg` varchar(30) DEFAULT '0' COMMENT '错误消息',
  `ok` varchar(30) DEFAULT '0' COMMENT '成功消息',
  `tip` varchar(30) DEFAULT '' COMMENT '提示消息',
  `decimals` tinyint(1) DEFAULT NULL COMMENT '小数点',
  `length` mediumint(8) DEFAULT NULL COMMENT '长度',
  `minimum` smallint(6) DEFAULT NULL COMMENT '最小数量',
  `maximum` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '最大数量',
  `isshowfront` tinyint(1) DEFAULT '0' COMMENT '是否前端显示',
  `isshowback` tinyint(1) DEFAULT '0' COMMENT '是否后台显示',
  `setting` varchar(1500) DEFAULT '' COMMENT '配置信息',
  `favisible` varchar(1500) DEFAULT '' COMMENT '显示条件',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '排序',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='项目字段';


--
-- List the data for the table
--

INSERT INTO `fa_miniform_fields` (`id`, `source`, `source_id`, `name`, `type`, `title`, `content`, `value`, `defaultvalue`, `rule`, `msg`, `ok`, `tip`, `decimals`, `length`, `minimum`, `maximum`, `isshowfront`, `isshowback`, `setting`, `favisible`, `weigh`, `createtime`, `updatetime`, `status`) VALUES
(1, 'ceshi', 1, 'name', 'string', '姓名', 'value1|title1\n                    value2|title2', NULL, '', '', '0', '0', '', 0, 50, NULL, 0, 1, 1, '{\"table\":\"\",\"conditions\":\"\",\"key\":\"\",\"value\":\"\"}', '', 1, 1709725382, 1709725382, 'normal'),
(2, 'ceshi', 1, 'mobile', 'string', '电话号码', 'value1|title1\n                    value2|title2', NULL, '', '', '0', '0', '', 0, 50, NULL, 0, 1, 1, '{\"table\":\"\",\"conditions\":\"\",\"key\":\"\",\"value\":\"\"}', '', 2, 1709725382, 1709725382, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_logs`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL COMMENT '用户ID',
  `diyform_id` int(10) DEFAULT '0' COMMENT '表单ID',
  `project_id` int(10) DEFAULT NULL COMMENT '项目ID',
  `status` enum('normal','nonpayment','refunding','canceled','expired') DEFAULT 'normal' COMMENT '状态:normal=正常,nonpayment=未支付,refunding=退款中,canceled=取消',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='项目记录';


--
-- List the data for the table
--

INSERT INTO `fa_miniform_logs` (`id`, `user_id`, `diyform_id`, `project_id`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 1, 1, 1, 'normal', 1709725477, 1709725477, NULL);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_order`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(32) NOT NULL DEFAULT '' COMMENT '订单号',
  `diyform_id` int(10) DEFAULT '0' COMMENT '表单ID',
  `project_id` int(10) DEFAULT '0' COMMENT '项目ID',
  `user_id` int(10) unsigned DEFAULT NULL COMMENT '用户ID',
  `logs_id` int(10) unsigned DEFAULT NULL COMMENT '数据ID',
  `amount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '订单金额',
  `payamount` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '支付金额',
  `ip` varchar(50) DEFAULT NULL COMMENT '下单IP',
  `useragent` varchar(255) DEFAULT NULL COMMENT 'UserAgent',
  `paytype` varchar(50) DEFAULT NULL COMMENT '支付类型',
  `paytime` bigint(16) DEFAULT NULL COMMENT '支付时间',
  `method` varchar(50) DEFAULT NULL COMMENT '支付方式',
  `memo` varchar(255) DEFAULT NULL COMMENT '备注',
  `status` enum('created','paid','expired','refunding','refunded') DEFAULT 'created' COMMENT '状态:created=未支付,paid=已支付,expired=已失效,refunding=退款中,refunded=已退款',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_project`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_project` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `category_id` int(10) DEFAULT NULL COMMENT '分类ID',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `images` varchar(1000) DEFAULT NULL COMMENT '图片',
  `people_num` int(10) DEFAULT '0' COMMENT '人数',
  `registered` int(10) unsigned DEFAULT '0' COMMENT '参与人数',
  `views` int(10) unsigned DEFAULT '0' COMMENT '浏览数',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '价格',
  `front_back` tinyint(4) DEFAULT NULL COMMENT '详情靠前或靠后',
  `is_multi` tinyint(1) DEFAULT '1' COMMENT '是否可多次提交',
  `is_signin` tinyint(1) DEFAULT '1' COMMENT '是否签到',
  `signin_time` varchar(100) DEFAULT '' COMMENT '签到时间',
  `signin_name` varchar(255) DEFAULT '' COMMENT '签到地点',
  `is_verification` tinyint(1) DEFAULT '0' COMMENT '是否开启活动核销',
  `is_need_login` tinyint(1) DEFAULT '1' COMMENT '是否需要登录:0=否,1=是',
  `iscaptcha` tinyint(1) DEFAULT '0' COMMENT '是否开启验证码:0=否,1=是',
  `content` text COMMENT '内容',
  `table` varchar(100) NOT NULL COMMENT '表单名称',
  `label` varchar(150) NOT NULL COMMENT '标签名称',
  `applyfields` varchar(1500) DEFAULT NULL COMMENT '报名字段',
  `begintime` bigint(16) DEFAULT NULL COMMENT '开始时间',
  `endtime` bigint(16) DEFAULT NULL COMMENT '结束时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  `status` enum('normal','hidden','expired') DEFAULT 'hidden' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='项目表';


--
-- List the data for the table
--

INSERT INTO `fa_miniform_project` (`id`, `category_id`, `title`, `images`, `people_num`, `registered`, `views`, `price`, `front_back`, `is_multi`, `is_signin`, `signin_time`, `signin_name`, `is_verification`, `is_need_login`, `iscaptcha`, `content`, `table`, `label`, `applyfields`, `begintime`, `endtime`, `createtime`, `updatetime`, `deletetime`, `status`) VALUES
(1, 1, '测试', '/assets/img/qrcode.png', 0, 1, 4, 0.00, 0, 1, 0, '', '{\"address\":\"\",\"lat\":\"\",\"lng\":\"\"}', 1, 1, 0, '测试', 'ceshi', '报名', NULL, 1709725367, 1710565367, 1709725382, 1709725382, NULL, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_staff`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_staff` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT '0' COMMENT '会员ID',
  `projectdata` varchar(1000) DEFAULT '' COMMENT '核销项目',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='核销员工表';


--
-- List the data for the table
--

INSERT INTO `fa_miniform_staff` (`id`, `user_id`, `projectdata`, `createtime`, `updatetime`) VALUES
(1, 1, '*', 1709725468, 1709725468);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_subscribe_log`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_subscribe_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL COMMENT '用户id',
  `logs_id` int(10) DEFAULT '0' COMMENT '日志id',
  `tpl_id` varchar(100) DEFAULT NULL COMMENT '模板id',
  `openid` varchar(100) DEFAULT NULL COMMENT 'Openid',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态:0=未发送,1=已发送',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订阅记录';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_miniform_template_msg`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_miniform_template_msg` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ident` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型:0=签到即将开始,1=签到即将结束,2=项目即将结束',
  `title` varchar(150) DEFAULT NULL COMMENT '标题',
  `tpl_id` varchar(50) DEFAULT NULL COMMENT '模板ID',
  `diy_text` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '自定义文本',
  `content` varchar(500) DEFAULT NULL COMMENT '内容',
  `page` varchar(100) DEFAULT NULL COMMENT '页面路径',
  `switch` tinyint(1) NOT NULL DEFAULT '0' COMMENT '开关',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ident` (`ident`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模板消息';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_notice`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) DEFAULT NULL COMMENT '消息名称',
  `event` varchar(255) DEFAULT NULL COMMENT '消息事件',
  `platform` enum('user','admin','mptemplate') DEFAULT 'user' COMMENT '平台:user=用户,admin=后台',
  `type` enum('msg','email','mptemplate','miniapp','sms') NOT NULL COMMENT '消息类型:msg=站内通知,email=邮箱通知',
  `to_id` int(255) NOT NULL COMMENT '接收人id',
  `content` text COMMENT '内容',
  `ext` text COMMENT '扩展',
  `notice_template_id` int(11) unsigned DEFAULT '0' COMMENT '消息模板',
  `readtime` bigint(16) DEFAULT NULL COMMENT '是否已读',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `notifications_notifiable_id_notifiable_type_index` (`to_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息通知';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_notice_admin_mptemplate`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_notice_admin_mptemplate` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(11) DEFAULT NULL COMMENT '管理员',
  `nickname` varchar(255) DEFAULT NULL COMMENT '微信昵称',
  `avatar` varchar(255) DEFAULT NULL COMMENT '微信头像',
  `openid` varchar(100) DEFAULT NULL,
  `unionid` varchar(100) DEFAULT NULL,
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员绑定微信(模版消息)';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_notice_event`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_notice_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `platform` set('user','admin') NOT NULL DEFAULT 'user' COMMENT '支持平台:user=用户,admin=后台',
  `type` set('msg','email','mptemplate','miniapp','sms') NOT NULL COMMENT '支持类型:msg=站内通知,email=邮箱通知',
  `name` varchar(50) NOT NULL COMMENT '消息名称',
  `event` varchar(50) NOT NULL COMMENT '消息事件',
  `send_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送次数',
  `send_fail_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送失败次数',
  `content` text COMMENT '参数',
  `visible_switch` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态:0=关闭,1=启用',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) unsigned DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `event` (`event`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息事件';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_notice_template`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_notice_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `notice_event_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '事件',
  `platform` enum('user','admin') NOT NULL DEFAULT 'user' COMMENT '平台:user=用户,admin=后台',
  `type` enum('msg','email','mptemplate','miniapp','sms') NOT NULL COMMENT '类型:msg=站内通知,email=邮箱通知',
  `mptemplate_id` varchar(100) DEFAULT '' COMMENT '微信公众号模板id',
  `mptemplate_json` varchar(3000) DEFAULT NULL COMMENT '公众号模版数据',
  `content` text COMMENT '消息内容',
  `visible_switch` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '状态:0=关闭,1=启用',
  `send_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送次数',
  `send_fail_num` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '发送失败次数',
  `ext` varchar(255) DEFAULT NULL COMMENT '扩展数据',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `url` varchar(300) DEFAULT NULL COMMENT 'url',
  `url_title` varchar(100) DEFAULT NULL COMMENT 'url标题',
  `url_type` tinyint(255) unsigned DEFAULT '1' COMMENT 'url类型:1=链接,2=弹窗,3=新窗口',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息模版';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_sms`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) DEFAULT '' COMMENT '事件',
  `mobile` varchar(20) DEFAULT '' COMMENT '手机号',
  `code` varchar(10) DEFAULT '' COMMENT '验证码',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) DEFAULT '' COMMENT 'IP',
  `createtime` bigint(16) unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='短信验证码表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_test`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) DEFAULT '0' COMMENT '会员ID',
  `admin_id` int(10) DEFAULT '0' COMMENT '管理员ID',
  `category_id` int(10) unsigned DEFAULT '0' COMMENT '分类ID(单选)',
  `category_ids` varchar(100) DEFAULT NULL COMMENT '分类ID(多选)',
  `tags` varchar(255) DEFAULT '' COMMENT '标签',
  `week` enum('monday','tuesday','wednesday') DEFAULT NULL COMMENT '星期(单选):monday=星期一,tuesday=星期二,wednesday=星期三',
  `flag` set('hot','index','recommend') DEFAULT '' COMMENT '标志(多选):hot=热门,index=首页,recommend=推荐',
  `genderdata` enum('male','female') DEFAULT 'male' COMMENT '性别(单选):male=男,female=女',
  `hobbydata` set('music','reading','swimming') DEFAULT NULL COMMENT '爱好(多选):music=音乐,reading=读书,swimming=游泳',
  `title` varchar(100) DEFAULT '' COMMENT '标题',
  `content` text COMMENT '内容',
  `image` varchar(100) DEFAULT '' COMMENT '图片',
  `images` varchar(1500) DEFAULT '' COMMENT '图片组',
  `attachfile` varchar(100) DEFAULT '' COMMENT '附件',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `city` varchar(100) DEFAULT '' COMMENT '省市',
  `json` varchar(255) DEFAULT NULL COMMENT '配置:key=名称,value=值',
  `multiplejson` varchar(1500) DEFAULT '' COMMENT '二维数组:title=标题,intro=介绍,author=作者,age=年龄',
  `price` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '价格',
  `views` int(10) unsigned DEFAULT '0' COMMENT '点击',
  `workrange` varchar(100) DEFAULT '' COMMENT '时间区间',
  `startdate` date DEFAULT NULL COMMENT '开始日期',
  `activitytime` datetime DEFAULT NULL COMMENT '活动时间(datetime)',
  `year` year(4) DEFAULT NULL COMMENT '年',
  `times` time DEFAULT NULL COMMENT '时间',
  `refreshtime` bigint(16) DEFAULT NULL COMMENT '刷新时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  `weigh` int(10) DEFAULT '0' COMMENT '权重',
  `switch` tinyint(1) DEFAULT '0' COMMENT '开关',
  `status` enum('normal','hidden') DEFAULT 'normal' COMMENT '状态',
  `state` enum('0','1','2') DEFAULT '1' COMMENT '状态值:0=禁用,1=正常,2=推荐',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='测试表';


--
-- List the data for the table
--

INSERT INTO `fa_test` (`id`, `user_id`, `admin_id`, `category_id`, `category_ids`, `tags`, `week`, `flag`, `genderdata`, `hobbydata`, `title`, `content`, `image`, `images`, `attachfile`, `keywords`, `description`, `city`, `json`, `multiplejson`, `price`, `views`, `workrange`, `startdate`, `activitytime`, `year`, `times`, `refreshtime`, `createtime`, `updatetime`, `deletetime`, `weigh`, `switch`, `status`, `state`) VALUES
(1, 1, 1, 12, '12,13', '互联网,计算机', 'monday', 'hot,index', 'male', 'music,reading', '我是一篇测试文章', '<p>我是测试内容</p>', '/assets/img/avatar.png', '/assets/img/avatar.png,/assets/img/qrcode.png', '/assets/img/avatar.png', '关键字', '我是一篇测试文章描述，内容过多时将自动隐藏', '广西壮族自治区/百色市/平果县', '{\"a\":\"1\",\"b\":\"2\"}', '[{\"title\":\"标题一\",\"intro\":\"介绍一\",\"author\":\"小明\",\"age\":\"21\"}]', 0.00, 0, '2020-10-01 00:00:00 - 2021-10-31 23:59:59', '2017-07-10', '2017-07-10 18:24:45', '2017', '18:24:45', 1491635035, 1491635035, 1491635035, NULL, 0, 1, 'normal', '1');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_user`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '组别ID',
  `username` varchar(32) DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) DEFAULT '' COMMENT '昵称',
  `password` varchar(32) DEFAULT '' COMMENT '密码',
  `salt` varchar(30) DEFAULT '' COMMENT '密码盐',
  `email` varchar(100) DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `bio` varchar(100) DEFAULT '' COMMENT '格言',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `successions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '连续登录天数',
  `maxsuccessions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '最大连续登录天数',
  `prevtime` bigint(16) DEFAULT NULL COMMENT '上次登录时间',
  `logintime` bigint(16) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) DEFAULT '' COMMENT '登录IP',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `joinip` varchar(50) DEFAULT '' COMMENT '加入IP',
  `jointime` bigint(16) DEFAULT NULL COMMENT '加入时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(50) DEFAULT '' COMMENT 'Token',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  `verification` varchar(255) DEFAULT '' COMMENT '验证',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COMMENT='会员表';


--
-- List the data for the table
--

INSERT INTO `fa_user` (`id`, `group_id`, `username`, `nickname`, `password`, `salt`, `email`, `mobile`, `avatar`, `level`, `gender`, `birthday`, `bio`, `money`, `score`, `successions`, `maxsuccessions`, `prevtime`, `logintime`, `loginip`, `loginfailure`, `joinip`, `jointime`, `createtime`, `updatetime`, `token`, `status`, `verification`) VALUES
(1, 1, 'admin', 'admin', '3c5a1356d2e5fdae82af9f8deda1056e', 'adlOUZ', 'admin@163.com', '13888888888', 'http://www.test.com/assets/img/avatar.png', 0, 0, '2017-04-08', '', 0.00, 0, 1, 1, 1491635035, 1709725459, '127.0.0.1', 0, '127.0.0.1', 1491635035, 0, 1709725459, '', 'normal', ''),
(201, 0, '13888888888', '李工', '59a20343750f7c60d495c040941b7433', 'dv92DA', '', '13888888888', '', 1, 0, NULL, '', 0.00, 0, 1, 1, 1669688805, 1669709986, '127.0.0.1', 0, '127.0.0.1', 1669688805, 1669688805, 1709880534, '', 'normal', ''),
(202, 0, '13666666666', '张工', 'f22fcb6d31e18c971a811192fecc8a13', 'i5Q8Io', '', '13666666666', '', 1, 0, NULL, '', 0.00, 0, 1, 1, 1669690876, 1669690876, '127.0.0.1', 0, '127.0.0.1', 1669690876, 1669690876, 1669690918, '', 'normal', ''),
(203, 0, '13555555555', '小王', 'b5c6360e246ede7bf0e16410237ed18f', 'KPtzp2', '', '13555555555', '', 1, 0, NULL, '', 0.00, 0, 1, 1, 1669710393, 1669710728, '127.0.0.1', 0, '127.0.0.1', 1669691760, 1669691760, 1669710728, '', 'normal', '');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_user_group`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT '' COMMENT '组名',
  `rules` text COMMENT '权限节点',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='会员组表';


--
-- List the data for the table
--

INSERT INTO `fa_user_group` (`id`, `name`, `rules`, `createtime`, `updatetime`, `status`) VALUES
(1, '默认组', '1,2,3,4,5,6,7,8,9,10,11,12', 1491635035, 1491635035, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_user_money_log`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_user_money_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更余额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前余额',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后余额',
  `memo` varchar(255) DEFAULT '' COMMENT '备注',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员余额变动表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_user_rule`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_user_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL COMMENT '父ID',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `title` varchar(50) DEFAULT '' COMMENT '标题',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `ismenu` tinyint(1) DEFAULT NULL COMMENT '是否菜单',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) DEFAULT '0' COMMENT '权重',
  `status` enum('normal','hidden') DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='会员规则表';


--
-- List the data for the table
--

INSERT INTO `fa_user_rule` (`id`, `pid`, `name`, `title`, `remark`, `ismenu`, `createtime`, `updatetime`, `weigh`, `status`) VALUES
(1, 0, 'index', 'Frontend', '', 1, 1491635035, 1491635035, 1, 'normal'),
(2, 0, 'api', 'API Interface', '', 1, 1491635035, 1491635035, 2, 'normal'),
(3, 1, 'user', 'User Module', '', 1, 1491635035, 1491635035, 12, 'normal'),
(4, 2, 'user', 'User Module', '', 1, 1491635035, 1491635035, 11, 'normal'),
(5, 3, 'index/user/login', 'Login', '', 0, 1491635035, 1491635035, 5, 'normal'),
(6, 3, 'index/user/register', 'Register', '', 0, 1491635035, 1491635035, 7, 'normal'),
(7, 3, 'index/user/index', 'User Center', '', 0, 1491635035, 1491635035, 9, 'normal'),
(8, 3, 'index/user/profile', 'Profile', '', 0, 1491635035, 1491635035, 4, 'normal'),
(9, 4, 'api/user/login', 'Login', '', 0, 1491635035, 1491635035, 6, 'normal'),
(10, 4, 'api/user/register', 'Register', '', 0, 1491635035, 1491635035, 8, 'normal'),
(11, 4, 'api/user/index', 'User Center', '', 0, 1491635035, 1491635035, 10, 'normal'),
(12, 4, 'api/user/profile', 'Profile', '', 0, 1491635035, 1491635035, 3, 'normal');
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_user_score_log`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_user_score_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '变更积分',
  `before` int(10) NOT NULL DEFAULT '0' COMMENT '变更前积分',
  `after` int(10) NOT NULL DEFAULT '0' COMMENT '变更后积分',
  `memo` varchar(255) DEFAULT '' COMMENT '备注',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员积分变动表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_user_token`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_user_token` (
  `token` varchar(50) NOT NULL COMMENT 'Token',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `expiretime` bigint(16) DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员Token表';


--
-- List the data for the table
--

INSERT INTO `fa_user_token` (`token`, `user_id`, `createtime`, `expiretime`) VALUES
('12b4359c798eb294e7992e322fa4bddbdb1c31d6', 1, 1709725460, 1712317460);
--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_version`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `oldversion` varchar(30) DEFAULT '' COMMENT '旧版本号',
  `newversion` varchar(30) DEFAULT '' COMMENT '新版本号',
  `packagesize` varchar(30) DEFAULT '' COMMENT '包大小',
  `content` varchar(500) DEFAULT '' COMMENT '升级内容',
  `downloadurl` varchar(255) DEFAULT '' COMMENT '下载地址',
  `enforce` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '强制更新',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='版本表';


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_webscan_log`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_webscan_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_time` int(10) NOT NULL,
  `page` varchar(100) DEFAULT NULL,
  `method` varchar(20) DEFAULT NULL,
  `rkey` varchar(50) DEFAULT NULL,
  `rdata` varchar(100) DEFAULT NULL,
  `user_agent` varchar(200) DEFAULT NULL,
  `request_url` varchar(200) DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `ip` varchar(50) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=229 DEFAULT CHARSET=utf8mb4;


--
-- Remove the table if it exists
--

DROP TABLE IF EXISTS `fa_webscan_verifies`;


--
-- Create the table if it not exists
--

CREATE TABLE IF NOT EXISTS `fa_webscan_verifies` (
  `nameid` int(32) NOT NULL AUTO_INCREMENT,
  `md5` varchar(32) NOT NULL DEFAULT '',
  `method` enum('local','official') NOT NULL DEFAULT 'official',
  `filename` varchar(254) NOT NULL DEFAULT '',
  `mktime` int(11) NOT NULL DEFAULT '0' COMMENT '最后修改时间',
  PRIMARY KEY (`nameid`)
) ENGINE=MyISAM AUTO_INCREMENT=36329 DEFAULT CHARSET=utf8;





