-- MySQL dump
-- version 1.0
--
-- SQL Dump created: June 30th, 2024 @ 11:45 pm

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- --------------------------------------------------------

--
-- Table structure for table `fa_equipment_archive`
--

DROP TABLE IF EXISTS `fa_equipment_archive`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_archive` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备型号',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备名称',
  `parameter` text COLLATE utf8mb4_unicode_ci COMMENT '设备参数',
  `amount` smallint(6) NOT NULL DEFAULT '0' COMMENT '设备数量',
  `supplier_id` bigint(20) DEFAULT '0' COMMENT '供应商',
  `purchasetime` bigint(20) DEFAULT '0' COMMENT '购置日期',
  `region` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '所在区域',
  `responsible_uid` bigint(20) DEFAULT '0' COMMENT '负责人',
  `document` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '设备文档',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备档案表';

--
-- Dumping data for table `fa_equipment_archive`
--

LOCK TABLES `fa_equipment_archive` WRITE;
INSERT INTO `fa_equipment_archive` (`id`, `model`, `name`, `parameter`, `amount`, `supplier_id`, `purchasetime`, `region`, `responsible_uid`, `document`, `remark`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(16, 'MC-T1650-HCS', '智慧消防灭火箱(文澄楼)', '灭火级别：1A 55B，瓶身材质：碳钢', 8, 1, 1710000000, '文澄楼3~4楼', 201, '', '', 'normal', 1710061295, 1710061295, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_caution`
--

DROP TABLE IF EXISTS `fa_equipment_caution`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_caution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT '' COMMENT '设备编号',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `warning` varchar(255) DEFAULT '' COMMENT '报警信息',
  `createtime` bigint(20) DEFAULT NULL COMMENT '报警时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fa_equipment_caution_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='设备报警管理';

--
-- Dumping data for table `fa_equipment_caution`
--

LOCK TABLES `fa_equipment_caution` WRITE;
INSERT INTO `fa_equipment_caution` (`id`, `code`, `archive_id`, `warning`, `createtime`, `deletetime`) VALUES
(4, 'E240310-024', 16, '错误', 1710128133, NULL),
(5, 'E240310-024', 16, '错误', 1710128144, NULL),
(6, 'E240310-024', 16, 'Flammable gas detected.', 1710128419, NULL),
(7, 'E240310-024', 16, 'Flammable gas detected.', 1710148632, NULL),
(8, 'E240310-024', 16, '温度过高', 1712230778, NULL),
(9, 'E240310-024', 16, 'Flammable gas detected.', 1718893593, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_department`
--

DROP TABLE IF EXISTS `fa_equipment_department`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_department` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '部门名称',
  `equipment_manage` tinyint(1) NOT NULL DEFAULT '0' COMMENT '设备管理权限',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='部门管理表';

--
-- Dumping data for table `fa_equipment_department`
--

LOCK TABLES `fa_equipment_department` WRITE;
INSERT INTO `fa_equipment_department` (`id`, `name`, `equipment_manage`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, '管理部门', 1, 'normal', 1669688745, 1669688745, NULL),
(2, '维修部门', 1, 'normal', 1669688757, 1669688757, NULL),
(3, '生产部门', 0, 'normal', 1669688764, 1669688764, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_equipment`
--

DROP TABLE IF EXISTS `fa_equipment_equipment`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_equipment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `coding` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '唯一编码',
  `equipment_code` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '设备编号',
  `work_status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '设备状态',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备明细表';

--
-- Dumping data for table `fa_equipment_equipment`
--

LOCK TABLES `fa_equipment_equipment` WRITE;
INSERT INTO `fa_equipment_equipment` (`id`, `archive_id`, `coding`, `equipment_code`, `work_status`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(63, 16, 'EPVLEIJX', 'E240310-017', 'normal', 'normal', 1710061295, 1710062576, NULL),
(64, 16, 'EOKWXETF', 'E240310-018', 'normal', 'normal', 1710061295, 1710061295, NULL),
(65, 16, 'EPEMJALT', 'E240310-019', 'normal', 'normal', 1710061295, 1710061295, NULL),
(66, 16, 'EAMVDYOB', 'E240310-020', 'normal', 'normal', 1710061295, 1710061295, NULL),
(67, 16, 'EMKFPRCY', 'E240310-021', 'normal', 'normal', 1710061295, 1710061295, NULL),
(68, 16, 'EFSYZUNT', 'E240310-022', 'normal', 'normal', 1710061295, 1710061295, NULL),
(69, 16, 'EGXJILKZ', 'E240310-023', 'normal', 'normal', 1710061295, 1710061295, NULL),
(70, 16, 'EUOQGPMX', 'E240310-024', 'repairing', 'normal', 1710061295, 1719564764, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_failure_cause`
--

DROP TABLE IF EXISTS `fa_equipment_failure_cause`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_failure_cause` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '故障原因',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备故障原因表';

--
-- Dumping data for table `fa_equipment_failure_cause`
--

LOCK TABLES `fa_equipment_failure_cause` WRITE;
INSERT INTO `fa_equipment_failure_cause` (`id`, `name`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, '其他原因', 'normal', 1669709924, 1669709924, NULL),
(2, '灭火器压强不合格', 'normal', 1669709929, 1710088040, NULL),
(3, '维护保养不到位', 'normal', 1669709935, 1669709935, NULL),
(4, '过期', 'normal', 1669709945, 1710088006, NULL),
(5, '违规操作', 'normal', 1669709953, 1669709953, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_message`
--

DROP TABLE IF EXISTS `fa_equipment_message`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT '' COMMENT '设备编号',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `temp` float(5,1) DEFAULT '0.0' COMMENT '温度',
  `hum` float(5,1) DEFAULT '0.0' COMMENT '湿度',
  `press` float(5,2) DEFAULT '0.00' COMMENT '气压',
  `light` float(5,2) DEFAULT '0.00' COMMENT '光照强度',
  `sta` int(11) DEFAULT '0' COMMENT '烟雾类型',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '运行状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  `floor` int(11) DEFAULT '0' COMMENT '楼层',
  `x` float(10,2) DEFAULT NULL COMMENT 'X轴',
  `y` float(10,2) DEFAULT NULL COMMENT 'Y轴',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fa_equipment_message_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='设备状态信息';

--
-- Dumping data for table `fa_equipment_message`
--

LOCK TABLES `fa_equipment_message` WRITE;
INSERT INTO `fa_equipment_message` (`id`, `code`, `archive_id`, `temp`, `hum`, `press`, `light`, `sta`, `status`, `createtime`, `updatetime`, `deletetime`, `floor`, `x`, `y`) VALUES
(23, 'E240310-017', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088398, NULL, 0, NULL, NULL),
(24, 'E240310-018', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088406, NULL, 0, NULL, NULL),
(25, 'E240310-019', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088407, NULL, 0, NULL, NULL),
(26, 'E240310-020', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088410, NULL, 0, NULL, NULL),
(27, 'E240310-021', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088413, NULL, 0, NULL, NULL),
(28, 'E240310-022', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088414, NULL, 0, NULL, NULL),
(29, 'E240310-023', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710061295, 1710088417, NULL, 0, NULL, NULL),
(30, 'E240310-024', 16, 22.0, 10.0, 88.50, 67.20, 0, 0, 1710061295, 1714745810, NULL, 0, NULL, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_messagelog`
--

DROP TABLE IF EXISTS `fa_equipment_messagelog`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_messagelog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT '' COMMENT '设备编号',
  `archive_id` bigint(20) DEFAULT '0' COMMENT '设备档案ID',
  `temp` float(5,1) DEFAULT '0.0' COMMENT '温度',
  `hum` float(5,1) DEFAULT '0.0' COMMENT '湿度',
  `press` float(5,2) DEFAULT '0.00' COMMENT '气压',
  `light` float(5,2) DEFAULT '0.00' COMMENT '光照强度',
  `sta` int(11) DEFAULT '0' COMMENT '烟雾类型',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '运行状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '0',
  `floor` int(11) DEFAULT '0' COMMENT '楼层',
  `x` float(10,2) DEFAULT NULL COMMENT 'X轴',
  `y` float(10,2) DEFAULT NULL COMMENT 'Y轴',
  PRIMARY KEY (`id`),
  UNIQUE KEY `fa_equipment_messagelog_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='设备状态信息日志';

--
-- Dumping data for table `fa_equipment_messagelog`
--

LOCK TABLES `fa_equipment_messagelog` WRITE;
INSERT INTO `fa_equipment_messagelog` (`id`, `code`, `archive_id`, `temp`, `hum`, `press`, `light`, `sta`, `status`, `createtime`, `deletetime`, `floor`, `x`, `y`) VALUES
(3, 'E240310-024', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710065053, NULL, 0, NULL, NULL),
(4, 'E240310-024', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710066242, NULL, 0, NULL, NULL),
(5, 'E240310-024', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710075345, NULL, 0, NULL, NULL),
(6, 'E240310-017', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088398, NULL, 0, NULL, NULL),
(7, 'E240310-018', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088406, NULL, 0, NULL, NULL),
(8, 'E240310-019', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088407, NULL, 0, NULL, NULL),
(9, 'E240310-020', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088410, NULL, 0, NULL, NULL),
(10, 'E240310-021', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088413, NULL, 0, NULL, NULL),
(11, 'E240310-022', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088414, NULL, 0, NULL, NULL),
(12, 'E240310-023', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088417, NULL, 0, NULL, NULL),
(13, 'E240310-024', 16, 23.0, 10.0, 100.00, 300.00, 0, 0, 1710088418, NULL, 0, NULL, NULL),
(14, 'E240310-024', 16, 22.0, 10.0, 88.50, 67.20, 0, 0, 1710127084, NULL, 0, NULL, NULL),
(15, 'E240310-024', 16, 22.0, 10.0, 88.50, 67.20, 0, 0, 1710148322, NULL, 0, NULL, NULL),
(16, 'E240310-024', 16, 22.0, 10.0, 88.50, 67.20, 0, 0, 1710567285, NULL, 0, NULL, NULL),
(18, 'E240310-024', 16, 0.0, 0.0, 0.00, 0.00, 0, 1, 1714745771, NULL, 0, NULL, NULL),
(19, 'E240310-024', 16, 0.0, 0.0, 0.00, 0.00, 0, 0, 1714745810, NULL, 0, NULL, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_plan`
--

DROP TABLE IF EXISTS `fa_equipment_plan`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_plan` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `coding` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '唯一编码',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '计划名称',
  `type` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '计划类型',
  `periodicity` bigint(20) unsigned NOT NULL DEFAULT '1' COMMENT '计划周期',
  `first_duetime` bigint(20) DEFAULT NULL COMMENT '首次执行日期',
  `last_duetime` bigint(20) DEFAULT NULL COMMENT '计划结束日期',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划表';

--
-- Dumping data for table `fa_equipment_plan`
--

LOCK TABLES `fa_equipment_plan` WRITE;
INSERT INTO `fa_equipment_plan` (`id`, `coding`, `name`, `type`, `periodicity`, `first_duetime`, `last_duetime`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(7, 'POVRWGPB', '巡检计划001', 'inspection', 3, 1710086399, 1715356799, 'normal', 1710061331, 1710061331, NULL),
(8, 'PWKPGNMH', '保养计划001', 'maintenance', 7, 1710086399, 1715356799, 'normal', 1710061505, 1710061505, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_plan_archive`
--

DROP TABLE IF EXISTS `fa_equipment_plan_archive`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_plan_archive` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `archive_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '档案ID',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划设备关联表';

--
-- Dumping data for table `fa_equipment_plan_archive`
--

LOCK TABLES `fa_equipment_plan_archive` WRITE;
INSERT INTO `fa_equipment_plan_archive` (`id`, `plan_id`, `archive_id`, `createtime`, `deletetime`) VALUES
(14, 7, 16, 1710061331, NULL),
(15, 8, 16, 1710061505, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_plan_field`
--

DROP TABLE IF EXISTS `fa_equipment_plan_field`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_plan_field` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `label` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段名称',
  `name` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段命名',
  `type` char(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '字段类型',
  `default` char(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '默认值',
  `options` text COLLATE utf8mb4_unicode_ci COMMENT '选项',
  `attributes` text COLLATE utf8mb4_unicode_ci COMMENT '属性',
  `require` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否必填',
  `sort` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划字段表';

--
-- Dumping data for table `fa_equipment_plan_field`
--

LOCK TABLES `fa_equipment_plan_field` WRITE;
INSERT INTO `fa_equipment_plan_field` (`id`, `plan_id`, `label`, `name`, `type`, `default`, `options`, `attributes`, `require`, `sort`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(8, 8, '压力是否正常', 'input_0', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(9, 8, '保险装置等完好有效', 'input_1', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(10, 8, '是否在有效期内', 'input_2', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(11, 8, '压把是否正常', 'input_3', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(12, 8, '喷射软管有无异常', 'input_4', 'radio', '', '[\"\\u662f\",\"\\u5426\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(13, 8, '灭火器使用状态', 'input_5', 'radio', '', '[\"\\u672a\\u4f7f\\u7528\",\"\\u4f7f\\u7528\"]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(14, 8, '气压', 'input_6', 'number', '', '[]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(15, 8, '温度', 'input_7', 'number', '', '[]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(16, 8, '湿度', 'input_8', 'number', '', '[]', NULL, 1, 99, 'normal', 1709891138, 1709891138, NULL),
(17, 8, '其它情况说明', 'input_9', 'text', '', '[]', NULL, 0, 99, 'normal', 1709891138, 1709891138, NULL),
(18, 7, '检测烟感报警器的正确性', 'input_0', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(19, 7, '柜内各元件表面灰尘清理', 'input_1', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(20, 7, '电源检查', 'input_2', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(21, 7, '灭火器取下抖动防止结块', 'input_3', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(22, 7, '柜体全面保养', 'input_4', 'radio', '', '[\"\\u5df2\\u5b8c\\u6210\",\"\\u5b58\\u5728\\u95ee\\u9898\"]', NULL, 1, 99, 'normal', 1709891859, 1709891859, NULL),
(23, 7, '其它情况说明', 'input_5', 'text', '', '[]', NULL, 0, 99, 'normal', 1709891859, 1709891859, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_plan_task`
--

DROP TABLE IF EXISTS `fa_equipment_plan_task`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_plan_task` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `coding` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '唯一编码',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `equipment_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '设备ID',
  `task_uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '处理人ID',
  `status` char(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending' COMMENT '状态',
  `starttime` bigint(20) DEFAULT NULL COMMENT '开始时间',
  `duetime` bigint(20) DEFAULT NULL COMMENT '到期时间',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划任务表';

--
-- Dumping data for table `fa_equipment_plan_task`
--

LOCK TABLES `fa_equipment_plan_task` WRITE;
INSERT INTO `fa_equipment_plan_task` (`id`, `coding`, `plan_id`, `equipment_id`, `task_uid`, `status`, `starttime`, `duetime`, `createtime`, `updatetime`, `deletetime`) VALUES
(13869, 'TSYXPCGW', 7, 63, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13870, 'TVTZIBMW', 7, 64, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13871, 'TJGSPHYZ', 7, 65, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13872, 'TYJRQAOG', 7, 66, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13873, 'TTAOXMYU', 7, 67, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13874, 'TXDKTNJM', 7, 68, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13875, 'TRKQXBIE', 7, 69, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13876, 'TWYMDSCK', 7, 70, 0, 'pending', 1709827200, 1710086399, 1710061331, 1710061331, NULL),
(13877, 'TKJNSMBG', 7, 63, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13878, 'TDCXZNJV', 7, 64, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13879, 'TJCBSQIU', 7, 65, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13880, 'TKWCYDNZ', 7, 66, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13881, 'TFHSRZGX', 7, 67, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13882, 'TIYWPQBC', 7, 68, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13883, 'TJZMQANO', 7, 69, 0, 'pending', 1710086400, 1710345599, 1710061331, 1710061331, NULL),
(13884, 'TWXNMZGL', 7, 70, 202, 'finish', 1710086400, 1710345599, 1710061331, 1710133955, NULL),
(13885, 'TVPXWYLN', 7, 63, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13886, 'TINMOVQS', 7, 64, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13887, 'TDHXURLF', 7, 65, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13888, 'TFBJMLWR', 7, 66, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13889, 'TADRGFNY', 7, 67, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13890, 'TZDKOXMC', 7, 68, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13891, 'TBEKYSFM', 7, 69, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13892, 'TEPQONVK', 7, 70, 0, 'pending', 1710345600, 1710604799, 1710061331, 1710061331, NULL),
(13893, 'TNJTZIHY', 7, 63, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13894, 'TUCONMLJ', 7, 64, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13895, 'TMWUVRTZ', 7, 65, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13896, 'TFHDMENW', 7, 66, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13897, 'TRBTEYLC', 7, 67, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13898, 'TTEYMPRA', 7, 68, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13899, 'TWBQJLDG', 7, 69, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13900, 'TJREZLXP', 7, 70, 0, 'pending', 1710604800, 1710863999, 1710061331, 1710061331, NULL),
(13901, 'TMNBUKQP', 7, 63, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13902, 'TPFCNKGO', 7, 64, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13903, 'TDJKUWMP', 7, 65, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13904, 'TALFHTSY', 7, 66, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13905, 'TGQMNWXY', 7, 67, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13906, 'TXOIEVTH', 7, 68, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13907, 'TIVTNWBK', 7, 69, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13908, 'TRKFCQOT', 7, 70, 0, 'pending', 1710864000, 1711123199, 1710061331, 1710061331, NULL),
(13909, 'TKOVLMSD', 7, 63, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13910, 'TTSBLMKV', 7, 64, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13911, 'TBLQVFDK', 7, 65, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13912, 'TYAFGXBQ', 7, 66, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13913, 'TVWMGNHJ', 7, 67, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13914, 'TTZKYLQD', 7, 68, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13915, 'TUANZKEJ', 7, 69, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13916, 'TJFDOQSZ', 7, 70, 0, 'pending', 1711123200, 1711382399, 1710061331, 1710061331, NULL),
(13917, 'TBIENOFX', 7, 63, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13918, 'TBDMPCYE', 7, 64, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13919, 'TSXVEPKQ', 7, 65, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13920, 'TKOBVUFZ', 7, 66, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13921, 'TKSXODPM', 7, 67, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13922, 'TQNEPGLZ', 7, 68, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13923, 'TIQKETYS', 7, 69, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13924, 'TRPMTCLG', 7, 70, 0, 'pending', 1711382400, 1711641599, 1710061331, 1710061331, NULL),
(13925, 'TJKUVQWN', 7, 63, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13926, 'TROJYSEP', 7, 64, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13927, 'TOFKGBLV', 7, 65, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13928, 'TRAKXEZF', 7, 66, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13929, 'TQIPFMOB', 7, 67, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13930, 'TSJIQDOU', 7, 68, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13931, 'TQBWCNXK', 7, 69, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13932, 'TCGDBNKV', 7, 70, 0, 'pending', 1711641600, 1711900799, 1710061331, 1710061331, NULL),
(13933, 'TKNTFQAJ', 7, 63, 202, 'finish', 1711900800, 1712159999, 1710061331, 1712059495, NULL),
(13934, 'THSITGMU', 7, 64, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13935, 'THFYVDWJ', 7, 65, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13936, 'THZLOQPE', 7, 66, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13937, 'TJSNPZAG', 7, 67, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13938, 'TILVPXYB', 7, 68, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13939, 'TNUERXDY', 7, 69, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13940, 'TTZNOVDQ', 7, 70, 0, 'pending', 1711900800, 1712159999, 1710061331, 1710061331, NULL),
(13941, 'TKNCEJQZ', 7, 63, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13942, 'TTCKGLZE', 7, 64, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13943, 'TUAKVXRS', 7, 65, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13944, 'TBYKHJFX', 7, 66, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13945, 'TAVIRCJB', 7, 67, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13946, 'TEDMNWOX', 7, 68, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13947, 'TZAOJSWG', 7, 69, 0, 'pending', 1712160000, 1712419199, 1710061331, 1710061331, NULL),
(13948, 'THSOZKXD', 7, 70, 202, 'finish', 1712160000, 1712419199, 1710061331, 1712233681, NULL),
(13949, 'TLRXCNGE', 7, 63, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13950, 'TNIVPOMW', 7, 64, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13951, 'TBWHQTRA', 7, 65, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13952, 'TGESOMLZ', 7, 66, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13953, 'TZMRDHYO', 7, 67, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13954, 'TNUSOGTL', 7, 68, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13955, 'TXMTIRSJ', 7, 69, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13956, 'TXSJANHQ', 7, 70, 0, 'pending', 1712419200, 1712678399, 1710061331, 1710061331, NULL),
(13957, 'TPZGYKFR', 7, 63, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13958, 'THIOSLZG', 7, 64, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13959, 'TPESLGBZ', 7, 65, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13960, 'TIACMWVD', 7, 66, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13961, 'THQFTJWK', 7, 67, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13962, 'THAKYVFJ', 7, 68, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13963, 'TQXSJZNI', 7, 69, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13964, 'TWPYDMLX', 7, 70, 0, 'pending', 1712678400, 1712937599, 1710061331, 1710061331, NULL),
(13965, 'TQGJYRWF', 7, 63, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13966, 'TBPWQKEI', 7, 64, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13967, 'TGSXEFCI', 7, 65, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13968, 'TVMPRIUF', 7, 66, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13969, 'TVHQLMTS', 7, 67, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13970, 'TGIOTWCQ', 7, 68, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13971, 'TVJZCRQH', 7, 69, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13972, 'TAJQWBCO', 7, 70, 0, 'pending', 1712937600, 1713196799, 1710061331, 1710061331, NULL),
(13973, 'TMAHYBGS', 7, 63, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13974, 'TPHDUMXF', 7, 64, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13975, 'TMUTXSCV', 7, 65, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13976, 'TMGBHJCY', 7, 66, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13977, 'TPYWLHEK', 7, 67, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13978, 'TKNDEMLH', 7, 68, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13979, 'TKWSEZXP', 7, 69, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13980, 'TEJVUDHL', 7, 70, 0, 'pending', 1713196800, 1713455999, 1710061331, 1710061331, NULL),
(13981, 'TSOVKDRQ', 7, 63, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13982, 'TFIMJNWS', 7, 64, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13983, 'TBRVPMDI', 7, 65, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13984, 'TOCWTXRI', 7, 66, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13985, 'TYRSNLOK', 7, 67, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13986, 'TQBFOISA', 7, 68, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13987, 'TROXWFYZ', 7, 69, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13988, 'TVBRCKUD', 7, 70, 0, 'pending', 1713456000, 1713715199, 1710061331, 1710061331, NULL),
(13989, 'TSNMTVID', 7, 63, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13990, 'TLEPGKBM', 7, 64, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13991, 'TGDIVTQL', 7, 65, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13992, 'TRLBWAVU', 7, 66, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13993, 'TUZQCJHW', 7, 67, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13994, 'TYPVEBCK', 7, 68, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13995, 'TZUBWHMC', 7, 69, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13996, 'TCXNUGMJ', 7, 70, 0, 'pending', 1713715200, 1713974399, 1710061331, 1710061331, NULL),
(13997, 'TSKFAMBY', 7, 63, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(13998, 'TOSRCBVH', 7, 64, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(13999, 'TDLHEIFR', 7, 65, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14000, 'TUHPASNT', 7, 66, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14001, 'TRSVIPUF', 7, 67, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14002, 'TZUHMOQT', 7, 68, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14003, 'TCFGBLKP', 7, 69, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14004, 'TUEGPDBS', 7, 70, 0, 'pending', 1713974400, 1714233599, 1710061331, 1710061331, NULL),
(14005, 'TCSWAPZU', 7, 63, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14006, 'TFLGCAED', 7, 64, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14007, 'TRJDWSLE', 7, 65, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14008, 'TFNPYXUW', 7, 66, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14009, 'TSUYTKMP', 7, 67, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14010, 'TOSVBEZJ', 7, 68, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14011, 'TKNSHGEL', 7, 69, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14012, 'TYUXKISP', 7, 70, 0, 'pending', 1714233600, 1714492799, 1710061331, 1710061331, NULL),
(14013, 'TRYELIDH', 7, 63, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14014, 'TFRLJVOH', 7, 64, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14015, 'TPRMLNUE', 7, 65, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14016, 'TLBKEDAS', 7, 66, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14017, 'TMRUWNYS', 7, 67, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14018, 'TNYIHMLT', 7, 68, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14019, 'TJAVLQTF', 7, 69, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14020, 'TVEPRBQW', 7, 70, 0, 'pending', 1714492800, 1714751999, 1710061331, 1710061331, NULL),
(14021, 'TCMHWINU', 7, 63, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14022, 'TKUWHSEP', 7, 64, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14023, 'TWGCLBPY', 7, 65, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14024, 'TBZGPRYM', 7, 66, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14025, 'TQXKCGPE', 7, 67, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14026, 'TCEPWFLJ', 7, 68, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14027, 'TNKLBPZO', 7, 69, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14028, 'TEXACKPH', 7, 70, 0, 'pending', 1714752000, 1715011199, 1710061331, 1710061331, NULL),
(14029, 'TNUVIYJE', 7, 63, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14030, 'TOHIURSC', 7, 64, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14031, 'TIXTFBJG', 7, 65, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14032, 'TINYPAQU', 7, 66, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14033, 'TTWYVHRM', 7, 67, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14034, 'TJYCOHIN', 7, 68, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14035, 'TMPDFWZJ', 7, 69, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14036, 'TPVMNUSI', 7, 70, 0, 'pending', 1715011200, 1715270399, 1710061331, 1710061331, NULL),
(14037, 'TGBUQXIV', 7, 63, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14038, 'TRQDZCVF', 7, 64, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14039, 'TAWFTGRV', 7, 65, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14040, 'TUGAOKJH', 7, 66, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14041, 'TUWHSAQG', 7, 67, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14042, 'TCJYAKNQ', 7, 68, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14043, 'TYQPBCLF', 7, 69, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14044, 'TUTIMXQC', 7, 70, 0, 'pending', 1715270400, 1715356799, 1710061331, 1710061331, NULL),
(14045, 'TTUCLJIY', 8, 63, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14046, 'TJFLGHRZ', 8, 64, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14047, 'TOXZVDGH', 8, 65, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14048, 'TKPHESVC', 8, 66, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14049, 'TVLHSZRT', 8, 67, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14050, 'TGYBWHXL', 8, 68, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14051, 'TYHQDGUP', 8, 69, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14052, 'TGXUZERH', 8, 70, 0, 'pending', 1709481600, 1710086399, 1710061505, 1710061505, NULL),
(14053, 'TMUBGFQE', 8, 63, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14054, 'TBSAWLIO', 8, 64, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14055, 'TGUYOWDB', 8, 65, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14056, 'TDYQASJO', 8, 66, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14057, 'TYUXDIQR', 8, 67, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14058, 'TJXRSGUL', 8, 68, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14059, 'TRFLQEKV', 8, 69, 0, 'pending', 1710086400, 1710691199, 1710061505, 1710061505, NULL),
(14060, 'TNMUICLH', 8, 70, 202, 'finish', 1710086400, 1710691199, 1710061505, 1710133997, NULL),
(14061, 'TNCVDWHO', 8, 63, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14062, 'TZSHTQJC', 8, 64, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14063, 'TKBDVHRN', 8, 65, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14064, 'TRXGMEIH', 8, 66, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14065, 'TOGSFVWK', 8, 67, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14066, 'TVOGHYEP', 8, 68, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14067, 'TIEKPOCL', 8, 69, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14068, 'TOTNAZJE', 8, 70, 0, 'pending', 1710691200, 1711295999, 1710061505, 1710061505, NULL),
(14069, 'TCPAJTRD', 8, 63, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14070, 'TRAOBMGJ', 8, 64, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14071, 'TGZYMAQX', 8, 65, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14072, 'TVHQGKOL', 8, 66, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14073, 'TNQVYRMJ', 8, 67, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14074, 'TTEFPUXW', 8, 68, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14075, 'TEPAMDKR', 8, 69, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14076, 'TXUOATNH', 8, 70, 0, 'pending', 1711296000, 1711900799, 1710061505, 1710061505, NULL),
(14077, 'TILWQYFB', 8, 63, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14078, 'TWFZMTRK', 8, 64, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14079, 'THALCJMI', 8, 65, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14080, 'TNRCBHYS', 8, 66, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14081, 'TENIYQVB', 8, 67, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14082, 'TUKCTOYN', 8, 68, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14083, 'TWBDHFQG', 8, 69, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14084, 'TVCYBEZD', 8, 70, 0, 'pending', 1711900800, 1712505599, 1710061505, 1710061505, NULL),
(14085, 'TLAMXHZN', 8, 63, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14086, 'TSOYIJXQ', 8, 64, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14087, 'TFWONQSJ', 8, 65, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14088, 'TJZONAFW', 8, 66, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14089, 'TGSVHFTW', 8, 67, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14090, 'TYCUEDLI', 8, 68, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14091, 'TBOLXKIW', 8, 69, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14092, 'TFIMYUJL', 8, 70, 0, 'pending', 1712505600, 1713110399, 1710061505, 1710061505, NULL),
(14093, 'TPNTYOXQ', 8, 63, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14094, 'TQHNRBUI', 8, 64, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14095, 'TNTVJAIR', 8, 65, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14096, 'TMEAHGPN', 8, 66, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14097, 'TOEZXVLY', 8, 67, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14098, 'TDNHSJZF', 8, 68, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14099, 'TWMZRCDJ', 8, 69, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14100, 'TZBERWFA', 8, 70, 0, 'pending', 1713110400, 1713715199, 1710061505, 1710061505, NULL),
(14101, 'TSJXOFVM', 8, 63, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14102, 'TZFRLKAQ', 8, 64, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14103, 'TKBQMTIU', 8, 65, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14104, 'TGLDSJKF', 8, 66, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14105, 'TODUPNHQ', 8, 67, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14106, 'TNZVMSPL', 8, 68, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14107, 'TFAJHOYS', 8, 69, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14108, 'TCAUGZTK', 8, 70, 0, 'pending', 1713715200, 1714319999, 1710061505, 1710061505, NULL),
(14109, 'TCELSMWI', 8, 63, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14110, 'TQNCETOK', 8, 64, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14111, 'TKONAPSL', 8, 65, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14112, 'TBQIGSKJ', 8, 66, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14113, 'TTDMYCSU', 8, 67, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14114, 'TUXLOYIN', 8, 68, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14115, 'TOIVPFNR', 8, 69, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14116, 'TSMLHQPV', 8, 70, 0, 'pending', 1714320000, 1714924799, 1710061505, 1710061505, NULL),
(14117, 'TNXBMWRG', 8, 63, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14118, 'TTXYOPRK', 8, 64, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14119, 'TWNUQVYS', 8, 65, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14120, 'TBIMVEOX', 8, 66, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14121, 'TDIWULNC', 8, 67, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14122, 'TAJUKBMZ', 8, 68, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14123, 'TELHTFAG', 8, 69, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL),
(14124, 'TVGHNSPL', 8, 70, 0, 'pending', 1714924800, 1715356799, 1710061505, 1710061505, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_plan_user`
--

DROP TABLE IF EXISTS `fa_equipment_plan_user`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_plan_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `plan_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '计划ID',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备计划用户关联表';

--
-- Dumping data for table `fa_equipment_plan_user`
--

LOCK TABLES `fa_equipment_plan_user` WRITE;
INSERT INTO `fa_equipment_plan_user` (`id`, `plan_id`, `user_id`, `createtime`, `deletetime`) VALUES
(12, 7, 202, 1710061331, NULL),
(13, 7, 201, 1710061331, NULL),
(14, 8, 202, 1710061505, NULL),
(15, 8, 201, 1710061505, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_record`
--

DROP TABLE IF EXISTS `fa_equipment_record`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_record` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `equipment_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '设备ID',
  `relate_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '关联ID',
  `add_uid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '添加用户ID',
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '记录名称',
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '记录类型',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '记录内容',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备记录表';

--
-- Dumping data for table `fa_equipment_record`
--

LOCK TABLES `fa_equipment_record` WRITE;
INSERT INTO `fa_equipment_record` (`id`, `equipment_id`, `relate_id`, `add_uid`, `name`, `type`, `content`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 63, 1, 202, '维修结果：已维修', 'repair', '[]', 'normal', 1710062576, 1710062576, NULL),
(2, 70, 13884, 202, '巡检结果：正常', 'inspection', '{\"images\":[\"https:\\/\\/loongson.cgsjzs.com\\/uploads\\/20240311\\/177d6c1459ea1f2558aae08dede89911.jpg\"],\"remark\":\"\\u65e0\\u8bef\",\"form_data\":[{\"label\":\"\\u68c0\\u6d4b\\u70df\\u611f\\u62a5\\u8b66\\u5668\\u7684\\u6b63\\u786e\\u6027\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u67dc\\u5185\\u5404\\u5143\\u4ef6\\u8868\\u9762\\u7070\\u5c18\\u6e05\\u7406\",\"value\":\"\\u5b58\\u5728\\u95ee\\u9898\"},{\"label\":\"\\u7535\\u6e90\\u68c0\\u67e5\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u706d\\u706b\\u5668\\u53d6\\u4e0b\\u6296\\u52a8\\u9632\\u6b62\\u7ed3\\u5757\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u67dc\\u4f53\\u5168\\u9762\\u4fdd\\u517b\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u5176\\u5b83\\u60c5\\u51b5\\u8bf4\\u660e\",\"value\":\"\\u65e0\"}],\"work_status\":\"\\u6b63\\u5e38\"}', 'normal', 1710133955, 1710133955, NULL),
(3, 70, 14060, 202, '保养完成', 'maintenance', '{\"images\":[\"https:\\/\\/loongson.cgsjzs.com\\/uploads\\/20240311\\/d193370fcad9b368cceac3c4b072ac72.jpg\"],\"remark\":\"\",\"form_data\":[{\"label\":\"\\u538b\\u529b\\u662f\\u5426\\u6b63\\u5e38\",\"value\":\"\\u662f\"},{\"label\":\"\\u4fdd\\u9669\\u88c5\\u7f6e\\u7b49\\u5b8c\\u597d\\u6709\\u6548\",\"value\":\"\\u5426\"},{\"label\":\"\\u662f\\u5426\\u5728\\u6709\\u6548\\u671f\\u5185\",\"value\":\"\\u662f\"},{\"label\":\"\\u538b\\u628a\\u662f\\u5426\\u6b63\\u5e38\",\"value\":\"\\u662f\"},{\"label\":\"\\u55b7\\u5c04\\u8f6f\\u7ba1\\u6709\\u65e0\\u5f02\\u5e38\",\"value\":\"\\u662f\"},{\"label\":\"\\u706d\\u706b\\u5668\\u4f7f\\u7528\\u72b6\\u6001\",\"value\":\"\\u672a\\u4f7f\\u7528\"},{\"label\":\"\\u6c14\\u538b\",\"value\":\"20\"},{\"label\":\"\\u6e29\\u5ea6\",\"value\":\"20\"},{\"label\":\"\\u6e7f\\u5ea6\",\"value\":\"20\"},{\"label\":\"\\u5176\\u5b83\\u60c5\\u51b5\\u8bf4\\u660e\",\"value\":\"\\u65e0\"}]}', 'normal', 1710133997, 1710133997, NULL),
(4, 70, 2, 202, '维修结果：已维修', 'repair', '[]', 'normal', 1710134089, 1710134089, NULL),
(5, 63, 13933, 202, '巡检结果：正常', 'inspection', '{\"images\":[\"https:\\/\\/loongson.cgsjzs.com\\/uploads\\/20240402\\/a21e04747af635ebb08fa4779164d5a2.jpg\"],\"remark\":\"\",\"form_data\":[{\"label\":\"\\u68c0\\u6d4b\\u70df\\u611f\\u62a5\\u8b66\\u5668\\u7684\\u6b63\\u786e\\u6027\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u67dc\\u5185\\u5404\\u5143\\u4ef6\\u8868\\u9762\\u7070\\u5c18\\u6e05\\u7406\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u7535\\u6e90\\u68c0\\u67e5\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u706d\\u706b\\u5668\\u53d6\\u4e0b\\u6296\\u52a8\\u9632\\u6b62\\u7ed3\\u5757\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u67dc\\u4f53\\u5168\\u9762\\u4fdd\\u517b\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u5176\\u5b83\\u60c5\\u51b5\\u8bf4\\u660e\",\"value\":\"\\u65e0\"}],\"work_status\":\"\\u6b63\\u5e38\"}', 'normal', 1712059495, 1712059495, NULL),
(6, 70, 13948, 202, '巡检结果：正常', 'inspection', '{\"images\":[],\"remark\":\"\",\"form_data\":[{\"label\":\"\\u68c0\\u6d4b\\u70df\\u611f\\u62a5\\u8b66\\u5668\\u7684\\u6b63\\u786e\\u6027\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u67dc\\u5185\\u5404\\u5143\\u4ef6\\u8868\\u9762\\u7070\\u5c18\\u6e05\\u7406\",\"value\":\"\\u5b58\\u5728\\u95ee\\u9898\"},{\"label\":\"\\u7535\\u6e90\\u68c0\\u67e5\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u706d\\u706b\\u5668\\u53d6\\u4e0b\\u6296\\u52a8\\u9632\\u6b62\\u7ed3\\u5757\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u67dc\\u4f53\\u5168\\u9762\\u4fdd\\u517b\",\"value\":\"\\u5df2\\u5b8c\\u6210\"},{\"label\":\"\\u5176\\u5b83\\u60c5\\u51b5\\u8bf4\\u660e\",\"value\":\"\"}],\"work_status\":\"\\u6b63\\u5e38\"}', 'normal', 1712233682, 1712233682, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_reminder_users`
--

DROP TABLE IF EXISTS `fa_equipment_reminder_users`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_reminder_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `staff_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '员工ID',
  `type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='提醒人员表';

--
-- Dumping data for table `fa_equipment_reminder_users`
--

LOCK TABLES `fa_equipment_reminder_users` WRITE;
INSERT INTO `fa_equipment_reminder_users` (`id`, `staff_id`, `type`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 1, 'assign_repair', 'normal', 1710088315, 1710088315, NULL),
(2, 2, 'assign_repair', 'normal', 1710088326, 1710088326, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_repair`
--

DROP TABLE IF EXISTS `fa_equipment_repair`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_repair` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `repair_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '工单编号',
  `archive_id` bigint(20) unsigned NOT NULL COMMENT '档案ID',
  `equipment_id` bigint(20) unsigned NOT NULL COMMENT '设备ID',
  `register_uid` bigint(20) DEFAULT '0' COMMENT '报修人员',
  `registertime` bigint(20) DEFAULT '0' COMMENT '报修日期',
  `content` text COLLATE utf8mb4_unicode_ci COMMENT '报修登记',
  `register_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '报修配图',
  `repair_uid` bigint(20) DEFAULT '0' COMMENT '维修人员',
  `assigntime` bigint(20) DEFAULT '0' COMMENT '派单时间',
  `repairtime` bigint(20) DEFAULT '0' COMMENT '维修日期',
  `repair_content` text COLLATE utf8mb4_unicode_ci COMMENT '维修登记',
  `repair_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '维修配图',
  `failure_cause_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '故障原因ID',
  `consuming` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '维修耗时',
  `status` char(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '维修状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='设备维修表';

--
-- Dumping data for table `fa_equipment_repair`
--

LOCK TABLES `fa_equipment_repair` WRITE;
INSERT INTO `fa_equipment_repair` (`id`, `repair_code`, `archive_id`, `equipment_id`, `register_uid`, `registertime`, `content`, `register_image`, `repair_uid`, `assigntime`, `repairtime`, `repair_content`, `repair_image`, `failure_cause_id`, `consuming`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 'R240310-001', 16, 63, 202, 1710062521, '存在问题', '/uploads/20240310/431e6e50493c5e7de3b30a040df4fbc4.png', 202, 1710062546, 1710062576, '维修完毕', '/uploads/20240310/15f7505fec0af7807169b34491e5423d.png', 5, 55, 'repaired', 1710062521, 1710062576, NULL),
(2, 'R240311-001', 16, 70, 202, 1710134026, '存在问题', '/uploads/20240311/edb05a6df41964b0ba4c20efad48e6bd.jpg', 202, 1710134052, 1710134089, '无误', '/uploads/20240311/649fe13a11a40fb1580a5e78876d1cf4.jpg', 2, 63, 'repaired', 1710134026, 1710134089, NULL),
(3, 'R240628-001', 16, 70, 202, 1719564764, '该设备存在胀气现象，需及时更换。', '/uploads/20240628/a21e04747af635ebb08fa4779164d5a2.jpg', 0, 0, 0, NULL, '', 0, 0, 'pending', 1719564764, 1719564764, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_staff`
--

DROP TABLE IF EXISTS `fa_equipment_staff`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_staff` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` bigint(20) DEFAULT '0' COMMENT '用户ID',
  `department_id` bigint(20) DEFAULT '0' COMMENT '部门ID',
  `workno` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '工号',
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '职位',
  `openid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'OPENID',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='员工管理表';

--
-- Dumping data for table `fa_equipment_staff`
--

LOCK TABLES `fa_equipment_staff` WRITE;
INSERT INTO `fa_equipment_staff` (`id`, `user_id`, `department_id`, `workno`, `position`, `openid`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 201, 1, 'T001', '技术总监', '', 'normal', 1669688805, 1709888853, NULL),
(2, 202, 2, 'T003', '维保工', 'oydCR614Dfrr64FrMbZCDIEArjUI', 'normal', 1669690876, 1719561572, NULL),
(3, 203, 3, 'P002', '装配工', 'oydCR6yDojdaAAuCMsrT2XLfXS4s', 'normal', 1669691760, 1718074012, NULL);
UNLOCK TABLES;

--
-- Table structure for table `fa_equipment_supplier`
--

DROP TABLE IF EXISTS `fa_equipment_supplier`;

--
-- Create the table if it not exists
--

CREATE TABLE `fa_equipment_supplier` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `supplier_code` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '供应商编号',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '供应商名称',
  `relationship` char(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '合作关系',
  `bank` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '开户银行',
  `bank_account` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '银行账号',
  `contact` char(100) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '联系人',
  `contact_mobile` char(50) COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT '联系电话',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `status` enum('normal','hidden') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal' COMMENT '状态',
  `createtime` bigint(20) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(20) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(20) DEFAULT NULL COMMENT '删除时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='供应商管理表';

--
-- Dumping data for table `fa_equipment_supplier`
--

LOCK TABLES `fa_equipment_supplier` WRITE;
INSERT INTO `fa_equipment_supplier` (`id`, `supplier_code`, `name`, `relationship`, `bank`, `bank_account`, `contact`, `contact_mobile`, `remark`, `status`, `createtime`, `updatetime`, `deletetime`) VALUES
(1, 'GYS-0001', '成都成工消防器材有限公司', 'special', '成都银行郫都支行', '8888888888888888', '李四', '13456789871', '', 'normal', 1669690703, 1709888903, NULL),
(2, 'GYS-0002', '特级智慧消防设备供应有限公司', 'important', '建设银行郫都支行', '123123123123123', '王五', '13898764857', '', 'normal', 1669690738, 1709890266, NULL);
UNLOCK TABLES;




